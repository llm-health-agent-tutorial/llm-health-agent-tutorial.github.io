# Tutorial materials, October 12, 2026

This local package contains the code, datasets and teaching materials for **Prototyping Your Personal LLM Health Agent**, UbiComp/ISWC 2026, Shanghai.

Start with [participant setup](starter/SETUP.md), then open [the notebook index](starter/notebooks/README.md). Use the local Ollama path for open-ended LLM exercises. An API backend is optional. `HA_BACKEND=scripted` provides a deterministic offline path for fixed guided exercises.

- [Starter repository and quickstart](starter/README.md)
- [Complete material map](starter/MATERIALS.md)
- [GLOBEM public sample plus synthetic supplements](starter/data/globem_hybrid/README.md)
- [Fully synthetic seeded teaching scenario](starter/data/DATA_CARD.md)
- [Slides](starter/slides/)
- [Instructor and participant handouts](starter/materials/)
- [Completion audit](COURSE_READINESS_2026-09-12-v3.md)

The hybrid data include observed feature values from the official public GLOBEM sample with separately labeled synthetic additions. They do not include the full credentialed PhysioNet release. Synthetic supplements must not be interpreted as facts about the source participants. The GLOBEM hybrid is the default main exercise. Module 5 reads the separate synthetic scenario for its controlled confound case without changing the active agent profile.

These materials are complete locally; website publication requires pushing/deploying the prepared website source. No conference registration or external messages are sent by this package.
