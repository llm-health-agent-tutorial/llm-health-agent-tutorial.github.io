# Schedule update, September 14, 2026

The tutorial is planned for the afternoon of October 12, 2026, in Shanghai. Exact start and end times remain to be confirmed.

The updated [slides](starter/slides/README.md) show the afternoon session on the cover. The teaching sequence and exercise durations remain unchanged. The code, datasets and rehearsal evidence follow the [September 12 readiness record](COURSE_READINESS_2026-09-12-v3.md).
