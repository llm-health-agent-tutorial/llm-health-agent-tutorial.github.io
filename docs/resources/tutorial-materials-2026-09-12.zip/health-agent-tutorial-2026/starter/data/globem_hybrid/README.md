# GLOBEM public sample + synthetic teaching supplements

This profile imports real observed feature values from the official GLOBEM public sample
and adds explicitly synthetic fields to exercise all nine tutorial tables. The separate
synthetic confound case remains available for the controlled sleep/screen/deadline lesson.

The shipped profile contains **10 participants, 481 feature-days, and 11,544 synthetic
hourly heart-rate rows**. It uses `INS-W-sample_1`, with dates from 2018-04-13 to 2018-06-18.
Default example: `g10`, ending 2018-06-08. That user's final 28-day window contains 25 paired
nonmissing observations of sleep duration and night screen time. Missing values are retained.
The recent 7-day demo window has 7 jointly observed pairs; the end date is the user's final
jointly observed sleep/screen day, not a claim that later source rows are complete.

## Run

From the repository root, after installing the normal tutorial requirements:

```bash
HA_DATA_DIR=data/globem_hybrid python -m healthagent.cli.datacheck
```

Start a fresh process for the profile; do not switch an already-running notebook's cached data.
For an offline example using only observed sleep:

```bash
HA_DATA_DIR=data/globem_hybrid python - <<'PY'
from healthagent import config
from healthagent.tools.retrieval import query_sleep
print(config.DEMO_USER, config.dataset_today())
print(query_sleep(config.DEMO_USER, *config.recent_window()))
PY
```

The original `u01` answer and June 2026 epoch apply only to the separate synthetic case profile.
This profile has no planted sleep story. Treat the imported records as observational features,
and inspect missingness and provenance before interpreting an association.

Source dates are feature-day labels: RAPIDS sleep-summary bedtime/duration and wake time can
refer to different nights in the same row, and decimal bedtimes may exceed 24. The 00:00–06:00
screen window is on the source date. A correlation joined by date is a source-day association,
not same-night evidence or proof of temporal order. This is recorded in metadata's
`time_alignment_note`; source dates and values have not been shifted to suggest episode alignment.
Efficiency is the Fitbit score divided by 100, not asleep/in-bed ratio; activity minutes are
step-threshold bouts; phone metrics describe unlock episodes; location metrics describe
upstream Barnett estimates and significant-location clusters. Barnett already imputes GPS;
`is_imputed=False` means only that this adapter did not fill missing feature values.

Social-app minutes are a labelled conditional simulation bounded by observed total unlock
duration, with nulls when that total is missing. Their association with the total is constructed,
not empirical evidence. See [the data card](DATA_CARD.md) for examples and official definitions.

## Rebuild and verify

The committed sources allow an offline rebuild; no credentials or network are needed:

```bash
python data/build_globem_hybrid.py
python -m pytest tests/test_globem_hybrid.py tests/test_globem_semantics.py -q
```

To restore the bundled source files from their exact upstream commit, verifying hashes:

```bash
python data/build_globem_hybrid.py --download-public
```

This command fetches only the documented public GitHub sample and its upstream documentation.
It never accesses PhysioNet. Parquet bytes can differ across library versions; the tests compare
the full data tables, their null patterns, and source values as well as provenance.

## Files

| File | Purpose |
|---|---|
| [DATA_CARD.md](DATA_CARD.md) | Observation/synthesis boundary, limitations, and licensing |
| [processed/](processed/) | Nine runnable tables, Parquet and CSV |
| [codebook.csv](codebook.csv) | Profile-specific metrics and units; night = 00:00–06:00 |
| [field_provenance.csv](field_provenance.csv) | Origin, source column, transformation, and notes for every output field |
| [dataset_metadata.json](dataset_metadata.json) | Default user/date, source kind, profile-specific codebook |
| [source_manifest.json](source_manifest.json) | Upstream commit, paths, URLs, Git blob SHA, and SHA-256 |
| [source/](source/) | Unmodified official public sample CSVs and documentation |
| [observed_ema.csv](observed_ema.csv) | All 30 original sparse EMA responses, including any survey-only dates |
| [build_source_manifest.json](build_source_manifest.json) | Files and counts consumed by the builder |
| [MANIFEST.sha256](MANIFEST.sha256) | Generated-artifact integrity hashes |
| [NOTICE.md](NOTICE.md) | Attribution and distinction from the restricted full release |

## Use a personally authorized full GLOBEM download

Complete-data access is managed by [PhysioNet](https://physionet.org/content/globem/1.1/).
After obtaining your own authorized local download, the same field adapter accepts the official
`INS-W_*/FeatureData`, `SurveyData`, and `ParticipantsInfoData` structure:

```bash
python data/build_globem_hybrid.py \
  --source-dir /path/to/authorized/globem \
  --source-kind globem_credentialed \
  --output-dir /path/to/private/globem-hybrid
HA_DATA_DIR=/path/to/private/globem-hybrid python -m healthagent.cli.datacheck
```

Credentialed output is required to live outside the public tutorial repository. The adapter
preserves observed numeric values and missingness, creates deterministic teaching supplements,
and records the local input hashes. This structural adapter has been exercised on the public
sample; **a complete credentialed dataset was not available for testing**. The resulting local
records remain subject to their source terms. Adding synthetic columns does not make restricted
observations redistributable. Keep them out of participant downloads, slides, and public repositories.
