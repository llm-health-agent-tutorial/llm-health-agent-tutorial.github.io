# Third-party attribution and data scope

The unmodified files in `source/INS-W-sample_1/` originate from the official
[UW-EXP/GLOBEM repository](https://github.com/UW-EXP/GLOBEM), commit
`4f140fc5290dc97204298cca28b956165aa0a29f`. The repository's Apache License 2.0 is retained
verbatim as `source/LICENSE`, together with its root and data documentation. Individual file
locations and integrity hashes are in `source_manifest.json`.

The tutorial changes are the adapter, unit conversions, tidy-table schema, synthetic supplements,
provenance records, and accompanying teaching documentation. They do not change upstream source
files. Synthetic values are invented teaching data and must not be attributed to the original
GLOBEM participants or authors.

Please cite the original work when using GLOBEM observations:

Xu, Xuhai, et al. 2022. *GLOBEM Dataset: Multi-Year Datasets for Longitudinal Human Behavior
Modeling Generalization.* NeurIPS Datasets and Benchmarks.
[Original publication](https://arxiv.org/abs/2211.02733).

For the complete versioned PhysioNet dataset, cite:

Xu, Xuhai, et al. 2023. *GLOBEM Dataset: Multi-Year Datasets for Longitudinal Human Behavior
Modeling Generalization (version 1.1).* PhysioNet.
[DOI: 10.13026/r9s1-s711](https://doi.org/10.13026/r9s1-s711).

The bundled GitHub sample is distinct from the complete PhysioNet release. The latter is
governed by its [credentialed health data license](https://physionet.org/content/globem/view-license/1.1/)
and [data-use agreement](https://physionet.org/content/globem/view-dua/1.1/).
The current license prohibits sharing access to restricted data. Adding synthetic columns or
renaming participant IDs does not remove that restriction. No complete credentialed source is
included in this tutorial profile.
