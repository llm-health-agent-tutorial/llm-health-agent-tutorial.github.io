# Data card: GLOBEM public sample + synthetic supplements

## Provenance and scope

**Observed portion:** the official [UW-EXP/GLOBEM public sample](https://github.com/UW-EXP/GLOBEM/tree/4f140fc5290dc97204298cca28b956165aa0a29f/data_raw/INS-W-sample_1),
pinned to commit `4f140fc5290dc97204298cca28b956165aa0a29f`. The upstream README describes its
bundled files as sample data from the datasets. We import the sleep, steps, screen, and location
CSV files, plus sparse EMA responses and phone-platform metadata. The source files remain unmodified.
This subset has 10 participants and 481 feature-days; it is not the full four-cohort release.

**Synthetic portion:** deterministic simulations supplied for unavailable teaching fields.
They are not participant reports, measurements, demographic facts, or validated imputations.
They must not be interpreted as evidence about a GLOBEM participant. No distribution parameters
are fitted to the observed data. Social-app minutes are a conditional simulation: a seeded
fraction of observed total unlock duration, rounded down, and null when that total is missing.
They cannot exceed the known total. Their dependence on that total is constructed, not an
empirical relationship. Other supplements retain their original simulations; the generator
never introduces the default tutorial's screen/sleep causal story into an observed trajectory.

The build emits 9 tables. The 7 daily tables each have 481 rows; users has 10 rows; hourly heart
rate has 11,544 simulated rows. All original 30 EMA records are preserved separately in
`observed_ema.csv`, and original survey columns are joined sparsely as `globem_<original_name>`.

## What is observed and what is invented?

| Table | Imported observations / deterministic conversions | Synthetic teaching supplements |
|---|---|---|
| sleep | Main-sleep duration, efficiency score, first bedtime, last wake time, unified awake-episode count | Deep and REM proportions |
| steps | Step count, active-bout minutes, sedentary-bout minutes | Walked distance and floors climbed |
| screen_time | Unlock duration, 00:00–06:00 unlock duration, unlock episodes, first use after midnight | Social-app minutes conditional on observed total (null when total is null); last-use time |
| location | Time at home, visited significant locations, location entropy, traveled distance | None |
| heart_rate | None | All heart rate and HRV values |
| heart_rate_hourly | Dates only | Entire hourly signal |
| ema | `globem_negative_affect_EMA`, preserving the original sparse scale | Mood, stress, energy, sleep quality, PHQ-2, response flags, timing, and text |
| context | Weekday/weekend derived from source dates; workday means weekday proxy | Weather, caffeine, event description |
| users | Original source keys, smartphone platform; first available date as enrollment proxy | Age band, sex, chronotype, sleep goal, steps goal |

The complete machine-readable [field provenance](field_provenance.csv) includes every column:
`table, metric, origin, source_column, transformation, notes`. Origins are `observed`,
`synthetic`, `derived`, or `unavailable`. Here `observed` includes explicitly documented unit
conversions; aliases preserve the same origin. `source_dataset` and `source_pid` retain the
upstream key. The `g01`–`g10` aliases do not establish additional anonymity.

## Missingness, time, and semantic boundaries

Missing observed entries remain null: 126 of 481 sleep-duration entries and 140 of 481
night-screen entries are missing. They are not replaced by invented values. Each observed
table lists `observed_missing_fields`; `is_imputed` is false because the adapter does not fill
observational gaps. Synthetic supplements remain labelled synthetic even when that flag is false.
The flag describes this adapter only. Upstream Barnett location processing already resamples
and imputes GPS before computing its features; imported location estimates are not untouched
raw GPS observations.

The GLOBEM `night` segment is **00:00–06:00**. The default fully synthetic dataset's segment is
**22:00–02:00**. They cannot be pooled as the same metric in a correlation or comparison.
Use this profile's codebook and metadata. Source duration units are retained or converted
explicitly (minutes → hours, meters → kilometers, efficiency score divided by 100); normalized,
discretized, and rolling-history columns are not substituted for daily quantities.

**Source dates are feature-day labels, not aligned sleep-episode dates.** RAPIDS sleep-summary
bedtime and duration use episodes starting between a source day's `LAST_NIGHT_END` and the next;
wake time uses episodes starting in the preceding interval. Thus a row's bedtime/duration and
wake may describe different nights. Bedtimes are hours relative to source-date midnight and
may exceed 24; first bedtime is a proxy, not measured sleep onset. Unified awake episodes are
counted across the source calendar day, not aligned to that row's sleep-summary interval or
interpretable as clinical awakening counts. We retain source-day values without shifting them.
Correlations joined by source date are **source-day associations, not same-night evidence**;
do not infer temporal order or causation from that join. The same guidance is stored in
`dataset_metadata.json` as `time_alignment_note`.

Fitbit efficiency is the source average score divided by 100, not a recalculated fraction of
time in bed spent asleep. For example, `INS-W_004` on `2018-05-13` has score 95 (output 0.95),
421 asleep minutes, and 461 in-bed minutes (ratio 0.9132). Activity and sedentary minutes mean
bouts classified using RAPIDS' step-count threshold, not exercise intensity or measured waking
sedentary behavior; all 397 nonmissing sample days sum to 1,440 minutes across these two fields,
so sleep/non-wear must not be silently excluded in interpretation. Screen duration and episode
count measure unlock activity, not all screen use or physical pickups. Location counts refer
to significant-location clusters rather than every distinct venue; home is inferred, and the
distance and entropy are upstream Barnett estimates.

GLOBEM's PANAS negative-affect score is not renamed or rescaled into a daily mood,
stress, or PHQ-2 report. Source dates are privacy-shifted study dates, not actual current calendar
dates; the default query epoch is `2018-06-08`, chosen as user `g10`'s final jointly observed
sleep/screen day. Its 7-day recent window has 7 observed pairs, and its 28-day window has 25.

Observed-only source-day associations may be explored with missingness and time alignment
disclosed. Correlations involving
synthetic supplements describe the constructed teaching data, not an empirical relationship in
the original participants. The data are unsuitable for clinical inference or estimating effects
in a representative population.

## Reproducibility and access

`../build_globem_hybrid.py` reproduces the profile with seed `20260912`; the supplied source
manifest records upstream paths, commit, Git blob SHA, byte counts, and SHA-256 hashes. The
generated manifest covers data, codebook, metadata, and provenance. Tests compare each imported
metric against its upstream column and confirm that missing values stay missing.
Semantic regression tests additionally check an actual sleep-date counterexample, score-versus-
ratio distinction, conditional social-app constraints, and source-file Git blob identities.

Feature semantics follow the official RAPIDS 1.6 documentation for
[sleep summary](https://www.rapids.science/1.6/features/fitbit-sleep-summary/),
[sleep intraday](https://www.rapids.science/1.6/features/fitbit-sleep-intraday/),
[steps](https://www.rapids.science/1.6/features/fitbit-steps-intraday/),
[screen](https://www.rapids.science/1.6/features/phone-screen/), and
[Barnett locations](https://www.rapids.science/1.6/features/phone-locations/),
cross-checked against the [GLOBEM feature descriptions](https://physionet.org/content/globem/1.1/).

The upstream public repository carries [Apache License 2.0](source/LICENSE); its license and
documentation are retained with [attribution](NOTICE.md). This does not relicense the complete
credentialed PhysioNet resource. The full [GLOBEM v1.1 release](https://physionet.org/content/globem/1.1/)
requires credentialing, the specified CITI training, and a data-use agreement. It releases
feature-level data and surveys, not raw identifiable sensor streams. No full credentialed data
were downloaded, included here, or tested. The optional local adapter leaves such outputs outside
this public repository and does not grant redistribution rights.
