# Tutorial datasets

The repository now contains two runnable profiles. Select a profile **before starting Python**.

| Profile | Contents | Teaching role / selection |
|---|---|---|
| [Default GLOBEM + synthetic supplements](globem_hybrid/README.md) | 10 users / 481 feature-days from the official public GLOBEM sample, plus explicitly labeled synthetic fields | Main exercise, `g10`, dataset date `2018-06-08`; no override needed |
| Synthetic confound case | 12 fictional users, 112 days each; seeded sleep/screen/deadline lesson | M5 manual discussion; `HA_DATA_DIR=data` only for a separate synthetic agent process |

The GLOBEM profile is an actual import of upstream observed feature values, not merely
GLOBEM-inspired generated data. It is **the public GitHub sample, not the complete restricted
PhysioNet dataset**. See its [data card](globem_hybrid/DATA_CARD.md),
[field provenance](globem_hybrid/field_provenance.csv), and [source manifest](globem_hybrid/source_manifest.json).
The two profiles use different night-screen windows and must not be pooled for correlation analysis.

## Separate synthetic confound case (Module 5)

Fully **synthetic** multimodal sensing data — 12 users (`u01`–`u12`), 112 days each
(16 weeks), ending on the fixed epoch `DEMO_TODAY = 2026-06-05`. It exists only to teach LLM-agent
design; it describes no real person and is not clinical data.

| File | What |
|------|------|
| [`DATA_CARD.md`](DATA_CARD.md) | This synthetic case only — contents, seeded teaching signal + confound, and interpretation limits |
| [`codebook.csv`](codebook.csv) | schema: every metric → table, unit, dtype, aliases (the `MetricCatalog` reads this) |
| [`generate_dataset.py`](generate_dataset.py) | the deterministic generator (run offline; the output is committed) |
| [`processed/`](processed/) | the data: 9 tables as `*.parquet` (+ a `.csv` mirror) |
| [`MANIFEST.sha256`](MANIFEST.sha256) | integrity hashes (CI regenerates + re-checks the signal) |
| [`golden/`](golden/) | pre-rendered reference answers/plot for **instructor rescue only** (never used by tests) |

Regenerate the synthetic case with `python generate_dataset.py` from `data/` (or `make data-synthetic` from the repository root). This does not rebuild the default GLOBEM hybrid. Reproducible
byte-for-byte via the fixed `SEED = 2026`.

**The seeded story (disclosed):** in `u01`'s final 7 days, night-time screen use is ~6–10× baseline
and total sleep is generated causally downstream of it (≈ 5.65 h vs ≈ 7.44 h baseline) — alongside a
**collinear `deadline` confound** that *independently* costs sleep. See [`DATA_CARD.md`](DATA_CARD.md)
for why, and how it drives the Module-5 correlation-≠-causation discussion.

The main notebooks use observed GLOBEM source-date features, not raw sensor streams. Source-date joins do not establish that sleep and night screen describe the same night. M5 loads its synthetic tables separately for manual comparison; it does not change the main agent profile inside the kernel.
