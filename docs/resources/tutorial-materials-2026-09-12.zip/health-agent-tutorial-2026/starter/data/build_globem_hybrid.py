"""Build a source-traceable GLOBEM + synthetic teaching profile, offline by default.

The bundled source is the official public INS-W-sample_1, not the restricted
PhysioNet release. Observed columns retain missing values. Supplements are
labelled simulations, never presented as a participant's facts. Social-app
minutes are conditionally simulated within the observed unlock-duration total.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from urllib.request import urlopen

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
PUBLIC = HERE / "globem_hybrid"
SEED = 20260912
TIME_ALIGNMENT_NOTE = (
    "Source dates are feature-day labels, not aligned sleep-episode dates. RAPIDS sleep-summary "
    "bedtime/duration use episodes starting between that day's LAST_NIGHT_END and the next; "
    "wake time uses episodes starting in the preceding interval. A row's bedtime/duration and "
    "wake can describe different nights; decimal bedtimes may exceed 24. Night screen covers "
    "00:00-06:00 on the source date. Correlations joined by source date are source-day "
    "associations, not same-night evidence; do not infer temporal order or causation."
)
METRIC_DESCRIPTIONS = {
    "total_sleep_hours": "Observed main-sleep duration summed under RAPIDS source-day assignment; not aligned to the same row's wake time",
    "sleep_efficiency": "Observed Fitbit average efficiency score divided by 100; not a recalculated asleep/in-bed ratio",
    "sleep_onset_hhmm": "Observed first bedtime relative to source-date midnight; decimal hours may exceed 24; proxy for onset, not measured onset; not aligned to same-row wake time",
    "wake_hhmm": "Observed last wake time relative to source-date midnight; uses the preceding sleep-summary interval, unlike same-row bedtime/duration",
    "awakenings": "Observed unified awake-episode count within main sleep across the source calendar day; not a clinical awakening count or an episode-aligned count for same-row sleep duration",
    "steps": "Observed step count across the source calendar day",
    "active_minutes": "Observed minutes in active bouts classified by the RAPIDS step-count threshold; not exercise or moderate-to-vigorous activity minutes",
    "sedentary_minutes": "Observed minutes in sedentary bouts classified by the RAPIDS step-count threshold; may include sleep/non-wear, not measured waking sedentary behavior",
    "total_screen_minutes": "Observed total duration of phone unlock episodes across the source calendar day; excludes unmeasured screen use without unlocking",
    "night_screen_minutes": "Observed unlock duration in GLOBEM's 00:00-06:00 source-day window; differs from synthetic profile 22:00-02:00; not aligned to same-row sleep-summary bedtime/duration",
    "pickups": "Observed number of phone unlock episodes across the source calendar day; not physical phone pickups",
    "first_use_hhmm": "Observed hours from source-date midnight to the first unlock episode",
    "time_at_home_hours": "Upstream Barnett estimate of time at inferred home; source GPS is resampled and imputed before feature extraction",
    "num_places_visited": "Upstream Barnett count of visited significant-location clusters, not all distinct venues; source GPS is resampled and imputed",
    "location_entropy": "Upstream Barnett Shannon entropy of time across significant-location clusters (nats); source GPS is resampled and imputed",
    "total_distance_km": "Upstream Barnett distance traveled between pauses, converted from meters; source GPS is resampled and imputed",
}

# Exact upstream daily, unnormalized columns. Multipliers convert source units.
MAPPING = {
    "sleep": {
        "total_sleep_hours": ("sleep", "f_slp:fitbit_sleep_summary_rapids_sumdurationasleepmain:allday", 1 / 60),
        "sleep_efficiency": ("sleep", "f_slp:fitbit_sleep_summary_rapids_avgefficiencymain:allday", 0.01),
        "sleep_onset_hhmm": ("sleep", "f_slp:fitbit_sleep_summary_rapids_firstbedtimemain:allday", 1 / 60),
        "wake_hhmm": ("sleep", "f_slp:fitbit_sleep_summary_rapids_lastwaketimemain:allday", 1 / 60),
        "awakenings": ("sleep", "f_slp:fitbit_sleep_intraday_rapids_countepisodeawakeunifiedmain:allday", 1),
    },
    "steps": {
        "steps": ("steps", "f_steps:fitbit_steps_intraday_rapids_sumsteps:allday", 1),
        "active_minutes": ("steps", "f_steps:fitbit_steps_intraday_rapids_sumdurationactivebout:allday", 1),
        "sedentary_minutes": ("steps", "f_steps:fitbit_steps_intraday_rapids_sumdurationsedentarybout:allday", 1),
    },
    "screen_time": {
        "total_screen_minutes": ("screen", "f_screen:phone_screen_rapids_sumdurationunlock:allday", 1),
        "night_screen_minutes": ("screen", "f_screen:phone_screen_rapids_sumdurationunlock:night", 1),
        "pickups": ("screen", "f_screen:phone_screen_rapids_countepisodeunlock:allday", 1),
        "first_use_hhmm": ("screen", "f_screen:phone_screen_rapids_firstuseafter00unlock:allday", 1 / 60),
    },
    "location": {
        "time_at_home_hours": ("location", "f_loc:phone_locations_barnett_hometime:allday", 1 / 60),
        "num_places_visited": ("location", "f_loc:phone_locations_barnett_siglocsvisited:allday", 1),
        "location_entropy": ("location", "f_loc:phone_locations_barnett_siglocentropy:allday", 1),
        "total_distance_km": ("location", "f_loc:phone_locations_barnett_disttravelled:allday", 0.001),
    },
}
ALIASES = {
    "sleep": {"f_slp:duration": "total_sleep_hours", "f_slp:efficiency": "sleep_efficiency"},
    "steps": {"f_steps:count": "steps"},
    "screen_time": {"f_screen:total": "total_screen_minutes", "f_screen:night": "night_screen_minutes"},
    "location": {"f_loc:home_hours": "time_at_home_hours", "f_loc:entropy": "location_entropy"},
}


def verify_public_source(download: bool = False) -> dict:
    manifest = json.loads((PUBLIC / "source_manifest.json").read_text())
    for item in manifest["files"]:
        path = PUBLIC / item["path"]
        if download:
            with urlopen(item["url"], timeout=45) as response:
                payload = response.read()
            if hashlib.sha256(payload).hexdigest() != item["sha256"]:
                raise ValueError(f"Upstream checksum mismatch: {item['path']}")
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(payload)
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != item["sha256"]:
            raise ValueError(f"Missing or modified source: {path}; use --download-public to restore it")
    return manifest


def load_source(source: Path):
    cohorts = [source] if (source / "FeatureData").is_dir() else sorted(
        p.parent for p in source.glob("*/FeatureData") if p.is_dir()
    )
    if not cohorts:
        raise ValueError("Expected INS-W*/FeatureData/*.csv under --source-dir")
    frames, platforms, source_rows = {}, [], []
    for cohort in cohorts:
        for filename in ("sleep", "steps", "screen", "location", "ema"):
            relative = ("SurveyData" if filename == "ema" else "FeatureData") + f"/{filename}.csv"
            path = cohort / relative
            if not path.exists():
                continue
            wanted = {"pid", "date"} | {column for fields in MAPPING.values()
                       for src, column, _ in fields.values() if src == filename}
            df = pd.read_csv(path, low_memory=False,
                             usecols=None if filename == "ema" else lambda col: col in wanted)
            if not {"pid", "date"} <= set(df):
                raise ValueError(f"Missing pid/date in {path}")
            df["date"] = pd.to_datetime(df["date"], errors="raise").dt.strftime("%Y-%m-%d")
            if df[["pid", "date"]].isna().any().any() or df.duplicated(["pid", "date"]).any():
                raise ValueError(f"Null or duplicate source keys in {path}")
            df["source_dataset"] = cohort.name
            df["source_pid"] = df.pop("pid").astype(str)
            frames.setdefault(filename, []).append(df)
            source_rows.append({"path": str(path.relative_to(source) if source != cohort else Path(cohort.name) / relative),
                                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "rows": len(df)})
        platform = cohort / "ParticipantsInfoData" / "platform.csv"
        if platform.exists():
            pl = pd.read_csv(platform)
            pl["source_dataset"] = cohort.name
            pl["source_pid"] = pl.pop("pid").astype(str)
            platforms.append(pl)
    if not all(name in frames for name in ("sleep", "steps", "screen", "location")):
        raise ValueError("GLOBEM source must include sleep, steps, screen, and location CSVs")
    frames = {k: pd.concat(v, ignore_index=True) for k, v in frames.items()}
    keys = ["source_dataset", "source_pid", "date"]
    # Source feature days only: never fabricate observations for absent days.
    index = pd.concat([df[keys] for name, df in frames.items() if name != "ema"]).drop_duplicates().sort_values(keys).reset_index(drop=True)
    people = index[keys[:2]].drop_duplicates().reset_index(drop=True)
    people["user_id"] = [f"g{i + 1:02d}" for i in range(len(people))]
    index = index.merge(people, on=keys[:2], validate="many_to_one")
    return frames, index, people, source_rows, platforms


def build(source: Path, source_kind: str = "globem_public_sample"):
    frames, index, people, source_rows, platforms = load_source(source)
    rng = np.random.default_rng(SEED)
    n = len(index)
    keys = ["source_dataset", "source_pid", "date"]
    base = index[["user_id", "date", "source_dataset", "source_pid"]]
    tables = {name: base.copy() for name in ("sleep", "steps", "screen_time", "location", "heart_rate", "ema", "context")}
    provenance = []

    def record(table, metric, origin, source_column="", transformation="", notes=""):
        provenance.append(dict(table=table, metric=metric, origin=origin, source_column=source_column,
                               transformation=transformation, notes=notes))

    def synthetic(table, metric, values):
        tables[table][metric] = values
        record(table, metric, "synthetic", "", f"deterministic simulation, seed={SEED}",
               "Teaching supplement; not measured from, reported by, or an inferred fact about this participant")

    for table, fields in MAPPING.items():
        for metric, (source_table, column, multiplier) in fields.items():
            src = frames[source_table]
            if column not in src:
                tables[table][metric] = np.nan
                record(table, metric, "unavailable", column, "", "Source column absent; not synthesized or imputed")
                continue
            aligned = index[keys].merge(src[keys + [column]], on=keys, how="left", validate="one_to_one")[column]
            numeric = pd.to_numeric(aligned, errors="coerce")
            if (aligned.notna() & numeric.isna()).any():
                raise ValueError(f"Nonnumeric values in {column}")
            tables[table][metric] = numeric * multiplier
            note = METRIC_DESCRIPTIONS[metric] + "; missing source features remain missing; this adapter performs no rounding, clipping, or imputation"
            if table == "sleep" or metric == "night_screen_minutes":
                note += "; " + TIME_ALIGNMENT_NOTE
            record(table, metric, "observed", column, f"multiply by {multiplier:.16g}", note)

    # No observational missing value is filled. Only fields unavailable from the
    # selected GLOBEM release are supplemented. Nothing seeds the old u01 story.
    synthetic("sleep", "deep_pct", rng.uniform(0.12, 0.23, n).round(3))
    synthetic("sleep", "rem_pct", rng.uniform(0.16, 0.28, n).round(3))
    synthetic("steps", "distance_km", rng.uniform(0.5, 9.0, n).round(2))
    synthetic("steps", "floors", rng.integers(0, 16, n))
    # Reuse the original integer draws so all later synthetic values remain stable.
    social_fraction = rng.integers(5, 120, n) / 120
    tables["screen_time"]["social_app_minutes"] = np.floor(
        tables["screen_time"]["total_screen_minutes"] * social_fraction)
    record("screen_time", "social_app_minutes", "synthetic", "screen_time.total_screen_minutes",
           f"floor(total_screen_minutes * randint(5, 120) / 120); seed={SEED}; null if total is null",
           "Conditional teaching simulation bounded by observed total unlock duration; its association with the total is constructed, not empirical evidence; not an observed participant fact")
    synthetic("screen_time", "last_use_hhmm", rng.uniform(21, 26, n).round(2))
    synthetic("heart_rate", "resting_hr_bpm", rng.integers(52, 76, n))
    synthetic("heart_rate", "avg_hr_bpm", rng.integers(76, 100, n))
    synthetic("heart_rate", "max_hr_bpm", rng.integers(120, 175, n))
    synthetic("heart_rate", "hrv_rmssd_ms", rng.uniform(30, 75, n).round(1))
    responded = rng.random(n) < 0.75
    for metric in ("mood", "stress", "energy", "perceived_sleep_quality"):
        synthetic("ema", metric, np.where(responded, rng.integers(1, 6, n), np.nan))
    synthetic("ema", "phq2_score", np.where(responded, rng.integers(0, 7, n), np.nan))
    synthetic("ema", "prompt_hhmm", np.where(responded, 20.0, np.nan))
    synthetic("ema", "responded", responded)
    synthetic("ema", "free_text", np.where(responded, "Synthetic practice check-in; no participant diary was collected for this field.", None))
    if "ema" in frames:
        src = frames["ema"]
        # Preserve the actual sparse survey scale names: never rename PANAS as
        # PHQ-2, mood or stress. Survey-only dates stay in observed_ema.csv too.
        for col in src.columns.difference(keys):
            metric = "globem_" + col
            tables["ema"][metric] = index[keys].merge(src[keys + [col]], on=keys, how="left", validate="one_to_one")[col]
            record("ema", metric, "observed", "SurveyData/ema.csv:" + col, "identity; sparse date join", "Original survey scale; unrelated synthetic EMA fields must not be treated as actual responses")
    dates = pd.to_datetime(index["date"])
    for metric, values in {"day_of_week": dates.dt.day_name(), "is_weekend": dates.dt.dayofweek >= 5,
                           "is_workday": dates.dt.dayofweek < 5}.items():
        tables["context"][metric] = values
        record("context", metric, "derived", "date", "calendar weekday; is_workday is a weekday proxy, not actual work attendance")
    synthetic("context", "weather", rng.choice(["clear", "cloudy", "rain"], n))
    synthetic("context", "caffeine_after_6pm", rng.random(n) < 0.18)
    synthetic("context", "event", np.repeat("synthetic teaching context; no measured event", n))

    tables["users"] = people.copy()
    for metric, values in {"age_band": rng.choice(["18-24", "25-34"], len(people)),
                           "sex": rng.choice(["F", "M", "nonbinary"], len(people)),
                           "chronotype": rng.choice(["early", "intermediate", "late"], len(people)),
                           "sleep_goal_hours": np.repeat(8.0, len(people)),
                           "steps_goal": np.repeat(8000, len(people))}.items():
        synthetic("users", metric, values)
    tables["users"]["enrolled_on"] = people.apply(lambda row: index.loc[(index.source_dataset == row.source_dataset) & (index.source_pid == row.source_pid), "date"].min(), axis=1)
    record("users", "enrolled_on", "derived", "date", "first available feature date; not actual enrollment date")
    if platforms:
        platform = pd.concat(platforms, ignore_index=True)
        for col in platform.columns.difference(keys[:2]):
            tables["users"][col] = people[keys[:2]].merge(platform, on=keys[:2], how="left", validate="one_to_one")[col]
            record("users", col, "observed", "ParticipantsInfoData/platform.csv:" + col, "identity")
    hourly = base.loc[base.index.repeat(24)].reset_index(drop=True)
    hours = np.tile(np.arange(24), n)
    hourly["datetime"] = (pd.to_datetime(hourly["date"]) + pd.to_timedelta(hours, unit="h")).dt.strftime("%Y-%m-%dT%H:%M:%S")
    hourly = hourly.drop(columns="date")
    tables["heart_rate_hourly"] = hourly
    resting = np.repeat(tables["heart_rate"]["resting_hr_bpm"].to_numpy(), 24)
    synthetic("heart_rate_hourly", "hr_bpm", (resting + 20 * np.sin(np.pi * np.maximum(0, hours - 6) / 16) ** 2 + rng.normal(0, 3, n * 24)).round().astype(int))
    record("heart_rate_hourly", "datetime", "derived", "date", "synthetic hourly grid; dates inherited from observed feature days")
    for table, fields in MAPPING.items():
        tables[table]["observed_missing_fields"] = tables[table][list(fields)].apply(lambda row: ";".join(row.index[row.isna()]), axis=1)
        tables[table]["is_imputed"] = False
        record(table, "is_imputed", "derived", "", "always false; this adapter does not fill missing source features",
               "Does not describe upstream processing; Barnett location features use resampled and imputed GPS")
        record(table, "observed_missing_fields", "derived", "", "semicolon list of unavailable observed metrics in this row")
        for alias, metric in ALIASES[table].items():
            tables[table][alias] = tables[table][metric]
            item = next(p for p in provenance if p["table"] == table and p["metric"] == metric)
            record(table, alias, item["origin"], item["source_column"], item["transformation"], f"Alias of {metric}; " + item["notes"])
    tables["heart_rate"]["is_imputed"] = False
    record("heart_rate", "is_imputed", "derived", "", "false denotes no imputation; all heart-rate values are synthetic")
    for table, df in tables.items():
        df["data_origin"] = source_kind + "+synthetic_supplements"
        for metric in ("user_id", "source_dataset", "source_pid", "date", "data_origin"):
            if metric in df:
                record(table, metric, "derived", "pid/date/source folder", "identity or deterministic ID mapping; see source manifest")
    quality = tables["sleep"][["user_id", "date", "total_sleep_hours"]].copy()
    quality["screen"] = tables["screen_time"]["night_screen_minutes"]
    scores = []
    for uid, group in quality.groupby("user_id", sort=True):
        valid = group[group[["total_sleep_hours", "screen"]].notna().all(axis=1)]
        if valid.empty:
            continue
        end = valid["date"].max()
        days = pd.to_datetime(valid["date"])
        week = (days >= pd.Timestamp(end) - pd.Timedelta(days=6)).sum()
        month = (days >= pd.Timestamp(end) - pd.Timedelta(days=27)).sum()
        scores.append((week, month, uid, end))
    if scores:
        paired_week, paired_month, demo_user, demo_today = max(scores)
    else:
        paired_week = paired_month = 0
        demo_user, demo_today = index.iloc[0]["user_id"], index.iloc[0]["date"]
    metadata = {"dataset_id": "globem-public-sample-hybrid-v1" if source_kind == "globem_public_sample" else "globem-local-hybrid-v1",
                "data_kind": "hybrid", "source_kind": source_kind, "demo_user": demo_user, "demo_today": demo_today,
                "codebook": "codebook.csv", "field_provenance": "field_provenance.csv",
                "description": "GLOBEM observed feature records with explicitly synthetic teaching supplements",
                "night_screen_window": "00:00-06:00", "seed": SEED,
                "time_alignment_note": TIME_ALIGNMENT_NOTE,
                "demo_recent_observed_pairs": int(paired_week), "demo_28day_observed_pairs": int(paired_month),
                "users": len(people), "person_days": n,
                "source_datasets": sorted(index.source_dataset.unique().tolist()),
                "date_min": index.date.min(), "date_max": index.date.max(),
                "observed_fields_are_imputed": False, "has_seeded_sleep_story": False,
                "full_physionet_release_included": False if source_kind == "globem_public_sample" else "unverified local input scope",
                "synthetic_supplement_warning": "Synthetic fields are invented teaching values, not facts about the GLOBEM participants; do not interpret cross-origin correlations as empirical evidence."}
    return tables, pd.DataFrame(provenance), metadata, source_rows, frames.get("ema")


def write_profile(out, tables, provenance, metadata, source_rows, observed_ema):
    processed = out / "processed"
    processed.mkdir(parents=True, exist_ok=True)
    for name, df in tables.items():
        df.to_csv(processed / f"{name}.csv", index=False)
        df.to_parquet(processed / f"{name}.parquet", index=False)
    provenance.to_csv(out / "field_provenance.csv", index=False)
    (out / "dataset_metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
    (out / "build_source_manifest.json").write_text(json.dumps(source_rows, indent=2) + "\n")
    if observed_ema is not None:
        observed_ema.to_csv(out / "observed_ema.csv", index=False)
    codebook = pd.read_csv(HERE / "codebook.csv", keep_default_na=False)
    actual = {(r.table, r.metric): r for r in provenance.itertuples()}
    for i, row in codebook.iterrows():
        origin = actual[(row["table"], row["metric"])].origin
        description = METRIC_DESCRIPTIONS.get(row["metric"], row["description"])
        if origin == "synthetic":
            description = "SYNTHETIC teaching supplement; not an observed participant fact. " + description
        if row["metric"] == "social_app_minutes":
            description = "SYNTHETIC conditional teaching supplement; simulated within observed total unlock minutes; null if total is null; not an observed participant fact or empirical association"
            codebook.at[i, "dtype"] = "float"
        if row["metric"] == "sleep_efficiency":
            codebook.at[i, "unit"] = "score_0_1"
        codebook.at[i, "description"] = description
        if origin == "observed":  # preserve original float-valued durations/counts
            codebook.at[i, "dtype"] = "float"
    codebook.to_csv(out / "codebook.csv", index=False)
    generated = list(processed.glob("*.csv")) + list(processed.glob("*.parquet")) + [out / x for x in ("field_provenance.csv", "dataset_metadata.json", "codebook.csv", "build_source_manifest.json")]
    if (out / "observed_ema.csv").exists():
        generated.append(out / "observed_ema.csv")
    (out / "MANIFEST.sha256").write_text("".join(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(out).as_posix()}\n" for p in sorted(generated)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--download-public", action="store_true", help="Restore pinned, checksummed public sample source files")
    parser.add_argument("--source-dir", type=Path, default=PUBLIC / "source")
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--source-kind", choices=["globem_public_sample", "globem_credentialed"], default="globem_public_sample")
    args = parser.parse_args()
    bundled = args.source_dir.resolve() == (PUBLIC / "source").resolve()
    if not bundled and (args.output_dir is None or args.source_kind != "globem_credentialed"):
        parser.error("External GLOBEM data requires --source-kind globem_credentialed and a separate --output-dir")
    out = (args.output_dir or PUBLIC).resolve()
    if not bundled and (out == PUBLIC.resolve() or HERE.parent.resolve() in out.parents):
        parser.error("Credentialed outputs must be outside this public tutorial repository")
    if bundled:
        verify_public_source(args.download_public)
        if args.source_kind != "globem_public_sample":
            parser.error("Bundled data is the public sample, not the credentialed full release")
    elif args.download_public:
        parser.error("--download-public only applies to the bundled public sample")
    result = build(args.source_dir, args.source_kind)
    write_profile(out, *result)
    print(json.dumps(result[2], indent=2))
    print(f"Wrote nine tables and field-level provenance to {out}")


if __name__ == "__main__":
    main()
