# Synthetic confound case: activity reference

Profile: fully synthetic, u01, query anchor 2026-06-05. This is not a GLOBEM answer.

Activity: 2026-05-30..2026-06-05 (7 calendar days; n=7 non-missing): recent avg 5956 steps/day is 25.5% below the goal of 8000. Baseline avg 7240 across 2026-05-09..2026-05-29 (21 calendar days; n=21 non-missing). (Synthetic data; for teaching context only.)

Numeric flag: `True`. This flag is not a complete factual, causal or clinical audit.

The change threshold is descriptive, not a p-value. For the Module-5 discussion, inspect the independently loaded context: the deadline and screen spike overlap, so their separate effects cannot be identified from this observation. The reference agent does not retrieve context by default.
