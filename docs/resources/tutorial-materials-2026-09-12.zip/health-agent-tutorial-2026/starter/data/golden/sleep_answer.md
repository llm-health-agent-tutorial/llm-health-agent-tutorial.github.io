# Synthetic confound case: sleep reference

Profile: fully synthetic, u01, query anchor 2026-06-05. This is not a GLOBEM answer.

In the final week of the dataset your sleep declined: total_sleep_hours down -24.1% (recent 5.65 vs baseline 7.44 hours; large descriptive change). One data-grounded hypothesis in this synthetic dataset is night-time screen use: night_screen_minutes up 854.8% (recent 89.57 vs baseline 9.38 minutes; large descriptive change). They move together (corr(total_sleep_hours, night_screen_minutes) = -0.93: strong negative association; n=28 paired observations within 2026-05-09..2026-06-05 (28 calendar days). Association only — not proof of cause). See the attached night-screen-time plot. Note: this is an association in synthetic data, not proof of cause; other factors could contribute.

Numeric flag: `True`. This flag is not a complete factual, causal or clinical audit.

The change threshold is descriptive, not a p-value. For the Module-5 discussion, inspect the independently loaded context: the deadline and screen spike overlap, so their separate effects cannot be identified from this observation. The reference agent does not retrieve context by default.
