# Golden outputs (opt-in rescue ONLY)

Pre-rendered reference answers + plots so a broken cell never blocks the next module. These are shown by EXPLICIT choice during the tutorial; nothing auto-falls-back to them, and verification never uses them.

These snapshots use the **separate fully synthetic confound profile**, user `u01`, dataset date `2026-06-05`,
and the fixed scripted backend. They are not answers for GLOBEM or another participant.
The Markdown answers were regenerated from the current reference agent on 2026-09-12; the existing
night-screen plot is retained. `grounded=True` is a minimal numeric check, not proof of causal or
clinical validity. The sleep answer includes a separate instructor note for the Module 5 manual review.

For current GLOBEM classroom runs, see [the real-model rehearsal](../../rehearsal/qwen3-8b-final-course/suite.json). These synthetic snapshots are only for the confound case.
