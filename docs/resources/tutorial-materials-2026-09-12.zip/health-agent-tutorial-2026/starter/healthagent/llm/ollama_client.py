"""Ollama adapter. Neutral history is translated to Ollama's (OpenAI-ish) message shape in chat();
neutral serialize_* (from the base) are reused. The SDK import is lazy so this module imports
without `ollama` installed.

Ollama's native API can't force a *named* tool, so `supports_force_tool=False` and `force_tool` is a
no-op here (the text nudge still applies); the signature-level completion check + hard fail-safe
remain the guarantee.
"""
from __future__ import annotations

import os
import inspect

from .client import LLMClient
from .errors import MissingSDK, ModelUnavailable
from .schemas import ChatResponse, ToolCall

DEFAULT_MODEL = "qwen3:8b"  # course model; other Ollama models remain configurable


def to_ollama_request(messages: list[dict]) -> list[dict]:
    """Neutral messages -> Ollama messages (pure; no SDK)."""
    out = []
    for m in messages:
        role = m.get("role")
        if role == "assistant" and m.get("tool_calls"):
            out.append({
                "role": "assistant",
                "content": m.get("content", ""),
                "tool_calls": [{"function": {"name": tc["name"], "arguments": tc.get("args", {})}}
                               for tc in m["tool_calls"]],
            })
        elif role == "tool":
            out.append({"role": "tool", "content": m.get("content", ""), "name": m.get("name", "")})
        else:
            out.append({"role": role, "content": m.get("content", "")})
    return out


def parse_ollama_response(message) -> ChatResponse:
    """Ollama message (obj or dict) -> neutral ChatResponse. Synthesizes ids (Ollama omits them)."""
    content = _attr(message, "content") or ""
    raw_calls = _attr(message, "tool_calls") or []
    tool_calls = []
    for i, tc in enumerate(raw_calls):
        fn = _attr(tc, "function") or {}
        name = _attr(fn, "name") or ""
        args = _attr(fn, "arguments")
        parse_error = None
        if isinstance(args, str):  # some models emit a JSON string
            import json
            try:
                args = json.loads(args)
            except (ValueError, TypeError) as exc:
                parse_error, args = f"invalid JSON arguments: {exc}", {}
        if not isinstance(args, dict):
            args = {}
        tool_calls.append(ToolCall(id=f"call_{i}_{name}", name=name, args=args, parse_error=parse_error))
    return ChatResponse(text=content, tool_calls=tool_calls, provider_raw=message)


def _attr(obj, name):
    if isinstance(obj, dict):
        return obj.get(name)
    return getattr(obj, name, None)


class OllamaBackend(LLMClient):
    provider = "ollama"
    supports_force_tool = False

    def __init__(self) -> None:
        try:
            import ollama  # lazy: module imports fine without the SDK
        except ImportError as exc:
            raise MissingSDK("ollama SDK not installed — run `make live-install`") from exc
        self._ollama = ollama
        self.host = os.getenv("OLLAMA_HOST", "http://localhost:11434")
        self.model = os.getenv("OLLAMA_MODEL", DEFAULT_MODEL)
        self.options = {
            "num_ctx": int(os.getenv("OLLAMA_NUM_CTX", "8192")),
            "num_predict": int(os.getenv("OLLAMA_NUM_PREDICT", "1536")),
            "temperature": float(os.getenv("OLLAMA_TEMPERATURE", "0")),
            "seed": int(os.getenv("OLLAMA_SEED", "2026")),
        }
        if self.options["num_ctx"] <= 0 or self.options["num_predict"] <= 0:
            raise ValueError("OLLAMA_NUM_CTX and OLLAMA_NUM_PREDICT must be positive")
        thinking = os.getenv("OLLAMA_THINK", "false" if self.model == DEFAULT_MODEL else "").strip().lower()
        if thinking not in {"", "true", "false", "low", "medium", "high"}:
            raise ValueError("OLLAMA_THINK must be true, false, low, medium, high, or unset")
        self.think = {"true": True, "false": False}.get(thinking, thinking or None)
        if self.think is not None and "think" not in inspect.signature(ollama.Client.chat).parameters:
            raise MissingSDK("Ollama thinking control requires SDK >=0.6; run `make live-install`")
        self._client = ollama.Client(host=self.host, timeout=float(os.getenv("OLLAMA_TIMEOUT", "180")))
        try:
            self._client.show(self.model)  # verify the model is actually pulled
        except Exception as exc:  # noqa: BLE001 - any failure means unusable
            raise ModelUnavailable(f"Ollama model '{self.model}' not available — run `ollama pull {self.model}`") from exc

    def chat(self, messages, tools=None, *, force_tool=None) -> ChatResponse:
        kwargs = {"options": self.options}
        if self.think is not None:
            kwargs["think"] = self.think
        resp = self._client.chat(model=self.model, messages=to_ollama_request(messages),
                                 tools=tools or None, **kwargs)
        parsed = parse_ollama_response(_attr(resp, "message") or resp)
        parsed.provider_raw = resp  # preserve model identity, token counts and timings for rehearsal
        return parsed
