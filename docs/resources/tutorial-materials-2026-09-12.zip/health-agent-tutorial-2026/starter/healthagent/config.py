"""Paths, constants, and backend resolution. Single source of truth at runtime."""
from __future__ import annotations

import os
import json
from datetime import date, timedelta
from pathlib import Path

from dotenv import load_dotenv

# Repo root = parent of the healthagent package directory.
ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")  # load first, so HA_DATA_DIR (etc.) may come from .env as well as the shell

DATA_DIR = ROOT / "data"
# Bring-your-own-data: HA_DATA_DIR (if set) is the directory that CONTAINS a processed/ subdir — i.e.
# the parent of processed/, mirroring the repo's data/. Must be set before the first data load
# (data.load_table is lru-cached). Select a profile before starting Python/Jupyter.
DEFAULT_DATA_DIR = DATA_DIR / "globem_hybrid"
ACTIVE_DATA_DIR = Path(os.getenv("HA_DATA_DIR", DEFAULT_DATA_DIR)).expanduser().resolve()
_metadata_path = ACTIVE_DATA_DIR / "dataset_metadata.json"
DATASET_METADATA = json.loads(_metadata_path.read_text()) if _metadata_path.exists() else {}
DATA_KIND = DATASET_METADATA.get("data_kind", "synthetic" if ACTIVE_DATA_DIR == DATA_DIR else "custom")
DATASET_DESCRIPTION = DATASET_METADATA.get("description", "Fully synthetic teaching scenario" if DATA_KIND == "synthetic" else "User-supplied dataset with unverified provenance")
NIGHT_SCREEN_WINDOW = DATASET_METADATA.get("night_screen_window", "22:00-02:00")
PROCESSED = ACTIVE_DATA_DIR / "processed"
CODEBOOK = (ACTIVE_DATA_DIR / DATASET_METADATA["codebook"]
            if "codebook" in DATASET_METADATA else DATA_DIR / "codebook.csv")
GOLDEN = DATA_DIR / "golden"
CACHE = ROOT / "cache"
FIGURES = CACHE / "figures"

# Dataset epoch + windows (mirror data/generate_dataset.py).
SEED = 2026
DEMO_USER = DATASET_METADATA.get("demo_user", "u01")
DEMO_TODAY = date.fromisoformat(DATASET_METADATA.get("demo_today", "2026-06-05"))
RECENT_DAYS = 7
BASELINE_DAYS = 21

TABLES = (
    "users", "sleep", "heart_rate", "heart_rate_hourly",
    "steps", "location", "screen_time", "ema", "context",
)


def recent_window() -> tuple[str, str]:
    """(start, end) ISO strings for the dataset's final RECENT_DAYS days, inclusive."""
    end = DEMO_TODAY
    start = end - timedelta(days=RECENT_DAYS - 1)
    return start.isoformat(), end.isoformat()


def baseline_window() -> tuple[str, str]:
    """(start, end) ISO strings for the BASELINE_DAYS window immediately before the recent week."""
    r_start = DEMO_TODAY - timedelta(days=RECENT_DAYS - 1)
    b_end = r_start - timedelta(days=1)
    b_start = b_end - timedelta(days=BASELINE_DAYS - 1)
    return b_start.isoformat(), b_end.isoformat()


def dataset_today() -> str:
    return DEMO_TODAY.isoformat()


def gemini_api_key() -> str | None:
    """Gemini credential. Accepts GEMINI_API_KEY (our documented name) OR GOOGLE_API_KEY (the
    google-genai SDK's native variable), so either works."""
    return os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")


def resolve_backend() -> str:
    """Desired backend: explicit choice, reachable local Ollama, cloud keys, scripted fallback."""
    explicit = os.getenv("HA_BACKEND", "").strip().lower()
    if explicit and explicit != "auto":
        return explicit
    # auto / empty -> detection chain (scripted is the always-available floor)
    if _ollama_reachable():
        return "ollama"
    # A pre-existing cloud key is not a choice to export credentialed data.
    if DATASET_METADATA.get("source_kind") == "globem_credentialed":
        return "scripted"
    if gemini_api_key():
        return "gemini"
    if os.getenv("OPENAI_API_KEY"):
        return "openai"
    return "scripted"


def _ollama_reachable(host: str | None = None) -> bool:
    host = host or os.getenv("OLLAMA_HOST", "http://localhost:11434")
    try:
        import urllib.request

        with urllib.request.urlopen(f"{host.rstrip('/')}/api/tags", timeout=0.4) as r:
            return r.status == 200
    except Exception:
        return False
