"""grounding.check — is the answer actually supported by retrieved evidence?

Prebuilt (Module-4 TODO-3 edits only the prompt, not this). The loop gates the public flag on the
`[GROUNDING]` marker (`grounded = (GROUNDING_MARKER in prompt) and grounding.check(...)`), so adding
the clause in TODO-3 is what makes the flag flip. The check requires every extracted number in
the answer must match (normalized) a number in a non-failed tool summary.

Matching rules (avoid false-pass AND false-fail):
- magnitude match within tolerance (so "dropped 24%" matches a "-23.9%" summary);
- a LITERAL signed contradiction is rejected (answer "+24" vs summary "-24");
- dates are ignored; window/sample counts must be supported but cannot ground an answer alone.
- at least one non-context answer value must match a non-context summary value.
Direction-word correctness (e.g. "increased 24%" vs a -24% summary) is asserted test-side in live
smoke, which knows the expected direction; the generic flag stays robust to phrasing.
"""
from __future__ import annotations

import math
import re

from ..llm.evidence import is_failed_tool_result
from ..llm.schemas import EvidenceRecord

_DATE = re.compile(r"\d{4}-\d{2}-\d{2}")
_VALUE = r"(?:\d+(?:,\d{3})*(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?"
_CONTEXT = re.compile(
    rf"\bn\s*=\s*[+-]?{_VALUE}\b|"
    rf"(?<![\w.])[+-]?{_VALUE}[-\s]+(?:(?:calendar|paired|dated|source)[-\s]+)?"
    r"(?:days?|nights?|observations?|pairs?|rows?|pts?|points?)\b", re.IGNORECASE,
)
_NUM = re.compile(rf"(?<![\w.])([+-]?)({_VALUE})")


def _numbers(text: str, *, exclude_context: bool = True) -> list[tuple[float, int]]:
    """Return (magnitude, sign) pairs. Always omit dates; optionally omit window/sample counts."""
    text = _DATE.sub(" ", text or "")
    text = re.sub(rf"(\*{{1,2}}|_{{1,2}}|`)([+-]?{_VALUE})\1", r"\2", text)
    if exclude_context:
        text = _CONTEXT.sub(" ", text)
    out: list[tuple[float, int]] = []
    for m in _NUM.finditer(text):
        s, n = m.group(1), m.group(2)
        sign = -1 if s == "-" else (1 if s == "+" else 0)
        out.append((float(n.replace(',', '')), sign))
    return out


def _close(a: float, b: float) -> bool:
    return (math.isfinite(a) and math.isfinite(b)
            and abs(a - b) <= max(0.5, 0.02 * max(abs(a), abs(b), 1.0)))


def check(answer_text: str, evidence: list[EvidenceRecord]) -> bool:
    usable = [e for e in (evidence or []) if not is_failed_tool_result(e.result)]
    if not usable:
        return False
    answer_values = _numbers(answer_text)
    measurement_nums: list[tuple[float, int]] = []
    all_summary_nums: list[tuple[float, int]] = []
    for e in usable:
        measurement_nums.extend(_numbers(e.result.summary or ""))
        all_summary_nums.extend(_numbers(e.result.summary or "", exclude_context=False))

    def matches(number, summary_numbers):
        a_mag, a_sign = number
        return any(_close(a_mag, s_mag) and not (a_sign and s_sign and a_sign != s_sign)
                   for s_mag, s_sign in summary_numbers)

    # Counts can support quoted counts, but neither an answer count nor a summary count
    # can supply the required measurement match. Every non-date number is still checked.
    # This screen does not verify metric identity, units, direction words, or causation.
    return (any(matches(number, measurement_nums) for number in answer_values)
            and all(matches(number, all_summary_nums)
                    for number in _numbers(answer_text, exclude_context=False)))
