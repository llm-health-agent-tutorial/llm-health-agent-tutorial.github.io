"""Read-only workshop plumbing that makes LIVE tool-use reliable, wired by `agent_config.run()`
in one line so the participant file keeps exactly three TODO blanks.

- `TOOL_POLICY`: tool-selection/order guidance only (NOT grounding — that stays the participant's
  `[GROUNDING]` clause, so TODO-3 still visibly matters).
- `completion_check`: SIGNATURE-level requirements (tool name + metric + date window), partitioned
  into `missing` (registered but not satisfied -> nudgeable) vs `unavailable` (not registered ->
  fail safe). Unrecognized intents return NO requirements (never gated).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Callable

from .. import config
from ..catalog import CATALOG, UnknownMetric
from ..llm.evidence import is_failed_tool_result
from ..llm.schemas import EvidenceRecord

_R0, _R1 = config.recent_window()
_SLEEP_KW = ("sleep", "slept", "sleeping", "tired", "rest", "insomnia", "bed", "fatigue")
_ACTIVITY_KW = ("activity", "active", "steps", "step ", "goal", "exercise", "walk", "move", "fitness")


@dataclass
class EvidenceRequirement:
    label: str
    tool_name: str
    args_match: Callable[[dict], bool]
    nudge_text: str


@dataclass
class CompletionCheckResult:
    missing: list[EvidenceRequirement] = field(default_factory=list)       # registered, not satisfied
    unavailable: list[EvidenceRequirement] = field(default_factory=list)   # tool not registered


def _metric_is(args: dict, target: str) -> bool:
    try:
        return CATALOG.resolve(args.get("metric", "")) == target
    except UnknownMetric:
        return False


def _recent_window(args: dict) -> bool:
    return args.get("start_date") == _R0 and args.get("end_date") == _R1


def _detect(args: dict, target: str) -> bool:
    return (_metric_is(args, target)
            and int(args.get("recent_days", 7)) == 7
            and int(args.get("baseline_days", 21)) == 21)


def _correlation(args: dict) -> bool:
    try:
        metrics = {CATALOG.resolve(args.get(key, "")) for key in ("metric_a", "metric_b")}
        return (metrics == {"total_sleep_hours", "night_screen_minutes"}
                and int(args.get("recent_days", 7)) == 7
                and int(args.get("baseline_days", 21)) == 21)
    except (UnknownMetric, TypeError, ValueError):
        return False


CORRELATION_REQ = EvidenceRequirement(
    "sleep-screen correlation", "correlate_metrics", _correlation,
    "call correlate_metrics with metric_a=total_sleep_hours, metric_b=night_screen_minutes, "
    "recent_days=7, baseline_days=21 before making an association claim",
)


SLEEP_REQS = [
    EvidenceRequirement("screen retrieval", "query_screen_time", _recent_window,
                        "call query_screen_time for the recent week (the 7 days ending at the demo query anchor)"),
    EvidenceRequirement("sleep retrieval", "query_sleep", _recent_window,
                        "call query_sleep for the recent week"),
    EvidenceRequirement("night-screen change", "detect_change",
                        lambda a: _detect(a, "night_screen_minutes"),
                        "call detect_change with metric=night_screen_minutes"),
    EvidenceRequirement("sleep change", "detect_change",
                        lambda a: _detect(a, "total_sleep_hours"),
                        "call detect_change with metric=total_sleep_hours"),
    EvidenceRequirement("night-screen plot", "plot_timeseries",
                        lambda a: _recent_window(a) and _metric_is(a, "night_screen_minutes"),
                        "call plot_timeseries with metric=night_screen_minutes for the recent week"),
]
ACTIVITY_REQS = [
    EvidenceRequirement("activity vs goal", "compare_window", lambda a: True, "call compare_window"),
]


def _association_intent(q: str) -> bool:
    if any(word in q for word in ("why", "cause", "correlat", "associat", "related")):
        return True
    # Defining a measure ("explain what this means") is not explaining a sleep change.
    return "explain" in q and any(word in q for word in
                                   ("change", "declin", "increas", "decreas", "worse", "poor", "drop"))


def _plot_requirements(q: str) -> list[EvidenceRequirement]:
    metrics = [m for m in CATALOG.metrics() if re.search(rf"(?<!\w){re.escape(m)}(?!\w)", q)]
    window = None
    explicit = re.search(r"(\d{4}-\d{2}-\d{2})\s*(?:to|through|\.\.|–|—)\s*(\d{4}-\d{2}-\d{2})", q)
    recent = re.search(r"\b(?:last|past|recent)\s+([1-9]\d{0,3})\s+days?\b", q)
    if explicit:
        try:
            window = tuple(date.fromisoformat(value).isoformat() for value in explicit.groups())
        except ValueError:
            pass  # An unparsed window adds no guessed date constraint.
    elif recent:
        end = config.DEMO_TODAY
        window = ((end - timedelta(days=int(recent.group(1)) - 1)).isoformat(), end.isoformat())
    requirements = []
    for metric in metrics or [None]:
        def matches(args, target=metric):
            return ((target is None or _metric_is(args, target))
                    and (window is None or (args.get("start_date"), args.get("end_date")) == window))
        detail = f" with metric={metric}" if metric else " for the requested metric"
        if window:
            detail += f", start_date={window[0]}, end_date={window[1]}"
        requirements.append(EvidenceRequirement("requested plot", "plot_timeseries", matches,
                                                "call plot_timeseries" + detail))
    return requirements


def requirements_for(question: str) -> list[EvidenceRequirement]:
    q = (question or "").lower()
    if re.search(r"\b(?:plot|chart|visuali[sz]e)\b", q) and not _association_intent(q):
        return _plot_requirements(q)
    if any(k in q for k in _SLEEP_KW):
        return SLEEP_REQS
    if any(k in q for k in _ACTIVITY_KW):
        return ACTIVITY_REQS
    return []  # unrecognized intent -> no requirements -> never completion-gated


def completion_check(question: str, evidence: list[EvidenceRecord], available_tools) -> CompletionCheckResult:
    avail = set(available_tools)
    res = CompletionCheckResult()
    requirements = requirements_for(question)
    if (requirements is SLEEP_REQS and "correlate_metrics" in avail
            and _association_intent(question.lower())):
        requirements = [*requirements, CORRELATION_REQ]
    for req in requirements:
        satisfied = any(
            ev.tool_call.name == req.tool_name
            and not is_failed_tool_result(ev.result)
            and req.args_match(ev.tool_call.args)
            for ev in evidence
        )
        if satisfied:
            continue
        (res.missing if req.tool_name in avail else res.unavailable).append(req)
    return res


TOOL_POLICY = (
    "\n\nTool use: for an explicit plot/chart/visualize request, respect the requested metric and "
    "date window. A request to explain what a measure means does not ask for causes of a sleep "
    "change; the requested plot can be sufficient without the sleep-change pipeline. "
    "To explain a change in sleep, call query_screen_time and query_sleep for the recent "
    "week, quantify both night_screen_minutes and total_sleep_hours with detect_change, and render "
    "plot_timeseries for night_screen_minutes before concluding. For an activity-vs-goal question, call "
    "compare_window. For sleep questions asking why, explaining a change, or about an association, "
    "call correlate_metrics if available with total_sleep_hours and night_screen_minutes, "
    "recent_days=7 and baseline_days=21. A correlation claim requires an actual successful "
    "correlate_metrics result; separate changes in means do not establish a correlation. "
    "Date-joined correlations are source-day associations, not same-night evidence, and do not "
    "establish temporal order or a cause of sleep changes. Use ISO YYYY-MM-DD dates; 'this week' means the 7 days ending at the demo query anchor."
)


def augment(system_prompt: str) -> tuple[str, Callable]:
    """Return (policy-augmented prompt, completion_check). One-line plumbing for agent_config.run()."""
    return system_prompt + TOOL_POLICY, completion_check
