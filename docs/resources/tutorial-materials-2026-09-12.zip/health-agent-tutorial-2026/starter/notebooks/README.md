# Notebook index

Use Python 3.10–3.12 (recommended 3.11). Prepare a local Ollama model for the full LLM path. Set `HA_BACKEND=scripted` for offline fixed exercises. The runtime prints the active backend.

| Module | Starter | Reference |
| --- | --- | --- |
| Preflight | [00 preflight](00_preflight.ipynb) | Setup checks |
| 1 | [introduction](01_introduction.ipynb) | [Completed notebook](solutions/01_introduction.ipynb) |
| 2 | [setting up](02_setting_up.ipynb) | [Completed notebook](solutions/02_setting_up.ipynb) |
| 3 | [designing tools](03_designing_tools.ipynb) | [Completed notebook](solutions/03_designing_tools.ipynb) |
| 4 | [wiring the agent](04_wiring_the_agent.ipynb) | [Completed notebook](solutions/04_wiring_the_agent.ipynb) |
| 5 | [eval safety](05_eval_safety.ipynb) | [Completed notebook](solutions/05_eval_safety.ipynb) |
| 6 | [wrap up](06_wrap_up.ipynb) | [Completed notebook](solutions/06_wrap_up.ipynb) |

Each module includes an optional advanced exercise. [Reference discussions](solutions/REFERENCE_ANSWERS.md) cover conceptual answers. The M3/M4 learner TODO files remain intentionally unfinished, while solution notebooks use completed imports.

The default main exercise is the GLOBEM public-sample hybrid (`g10`, dataset date `2018-06-08`).
Start `make lab` from the repository root with no stale `HA_DATA_DIR=data` override. Each notebook
prints the active profile, user and date; queries use `config.DEMO_USER`.

M3 has three required implementations: `query_screen_time`, `detect_change`, and `plot_timeseries`.
M4 registers all three student tools alongside provided sleep retrieval. M5 evaluates the main hybrid
agent, then directly reads the separate fully synthetic `u01` tables for a confound discussion.
Those local variables never change the agent's profile. M6 returns to the GLOBEM sleep comparison.

Use a fresh process/server when deliberately selecting another profile; changing a different terminal's
environment does not update an existing Jupyter server. Source dates are not necessarily same-night
alignment. Synthetic supplements cannot explain source participants' sleep, and missing data must not
be silently filled. See [complete material map](../MATERIALS.md).
