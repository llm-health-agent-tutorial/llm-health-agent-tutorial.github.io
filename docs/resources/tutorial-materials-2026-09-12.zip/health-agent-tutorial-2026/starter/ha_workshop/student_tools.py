"""YOUR Module-3 tools. Edit THIS file (the notebook prints its exact path).

- query_steps is PREFILLED as a second worked example.
- query_screen_time, detect_change, and plot_timeseries have small TODOs. Until filled they return a
  "TODO not implemented" result, so the agent will say it lacks evidence rather than make
  something up. Fill the TODO lines, then re-run the smoke-test cell in 03_designing_tools.ipynb.

Provided helpers (already imported): data.load_user_metric(...), and for detect_change the
window/series helpers _windows() and _series().
"""
from __future__ import annotations

import matplotlib
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from healthagent import config, data  # noqa: E402
from healthagent.catalog import CATALOG  # noqa: E402
from healthagent.llm.schemas import TODO_SENTINEL, ToolResult  # noqa: E402
from healthagent.tools.analysis import _series, _windows  # noqa: E402
from healthagent.tools.registry import tool  # noqa: E402


@tool
def query_steps(user_id: str, start_date: str, end_date: str) -> ToolResult:
    """Retrieve daily steps, active minutes and distance for a user over an inclusive date range. (PREFILLED example.)"""
    df = data.load_user_metric(user_id, "steps", ["steps", "active_minutes", "distance_km"], start_date, end_date)
    rows = df.assign(date=df["date"].dt.strftime("%Y-%m-%d")).to_dict("records")
    mean_steps = int(df["steps"].mean()) if len(df) else 0
    return ToolResult("table", f"{len(df)} days: mean {mean_steps} steps/day.", rows)


@tool
def query_screen_time(user_id: str, start_date: str, end_date: str) -> ToolResult:
    """Retrieve daily total and night-time (window defined by active dataset metadata) screen-time minutes for a user over an inclusive date range."""
    # === TODO-M3 (≈2 lines): load total_screen_minutes and night_screen_minutes for this
    #     user/date range, then return them. Hint:
    #   df = data.load_user_metric(user_id, "screen_time",
    #                              ["total_screen_minutes", "night_screen_minutes"], start_date, end_date)
    #   rows = df.assign(date=df["date"].dt.strftime("%Y-%m-%d")).to_dict("records")
    #   return ToolResult("table", f"{len(df)} days: mean night screen "
    #                              f"{round(df['night_screen_minutes'].mean(),1)} min.", rows)
    return ToolResult("text", TODO_SENTINEL, {})
    # === END TODO-M3 ===


@tool
def detect_change(user_id: str, metric: str, recent_days: int = 7, baseline_days: int = 21) -> ToolResult:
    """Compare a metric's recent-window mean to its prior baseline-window mean; report delta, percent change, direction, and a descriptive change flag (not statistical significance)."""
    r_start, r_end, b_start, b_end = _windows(recent_days, baseline_days)
    canonical, recent = _series(user_id, metric, r_start, r_end)
    _, base = _series(user_id, metric, b_start, b_end)
    if len(recent) == 0 or len(base) == 0:
        return ToolResult("text", f"tool error: no data for {canonical} in the requested windows", {}, error=True)

    # === TODO-M3 (exactly 2 lines): compute the two window means ===
    recent_mean = None    # TODO: float(recent.mean())
    baseline_mean = None  # TODO: float(base.mean())
    # === END TODO-M3 ===

    if recent_mean is None or baseline_mean is None:
        return ToolResult("text", TODO_SENTINEL, {})

    delta = recent_mean - baseline_mean
    pct = (delta / baseline_mean * 100) if baseline_mean else float("nan")
    z = delta / (float(base.std()) or 1e-9)
    direction = "up" if delta > 0 else ("down" if delta < 0 else "flat")
    unit = CATALOG.unit_for(canonical)
    out = {
        "metric": canonical, "recent_mean": round(recent_mean, 2), "baseline_mean": round(baseline_mean, 2),
        "delta": round(delta, 2), "pct_change": round(pct, 1), "direction": direction,
        "significant": bool(abs(z) > 1.5), "unit": unit,
        "recent_window": [r_start, r_end], "baseline_window": [b_start, b_end],
    }
    sig = "large descriptive change" if out["significant"] else "descriptive threshold not exceeded"
    return ToolResult(
        "text",
        f"{canonical} {direction} {out['pct_change']}% (recent {out['recent_mean']} vs "
        f"baseline {out['baseline_mean']} {unit}; {sig}).",
        out,
    )


@tool
def plot_timeseries(user_id: str, metric: str, start_date: str, end_date: str) -> ToolResult:
    """Plot a daily metric with gaps for missing observations; return a PNG and numeric summary."""
    canonical = CATALOG.resolve(metric)
    df = data.load_user_metric(user_id, CATALOG.table_for(canonical), [canonical],
                               start_date, end_date)
    if df.empty or not df[canonical].notna().any():
        return ToolResult("text", f"tool error: no data to plot for {canonical}", {}, error=True)
    # Keep NaNs and add absent dates: the line must stop at gaps, not bridge them.
    df = (df.set_index("date").reindex(pd.date_range(start_date, end_date, freq="D"))
          .rename_axis("date").reset_index())
    fig, ax = plt.subplots(figsize=(7, 3))

    # === TODO-M3-PLOT (3 lines): draw the series and label both axes ===
    # Use df["date"] as x and df[canonical] as y; keep the NaNs in place.
    # Hint: ax.plot(..., marker="o", ms=3)
    # Label the x axis "Date" and the y axis with CATALOG.unit_for(canonical).
    # Hint: ax.set_xlabel(...); ax.set_ylabel(...)
    pass  # TODO: plot the values and set the two axis labels
    # === END TODO-M3-PLOT ===

    if not ax.lines or not ax.get_xlabel() or not ax.get_ylabel():
        plt.close(fig)
        return ToolResult("text", TODO_SENTINEL, {})
    ax.set_title(f"{user_id}: {canonical}")
    fig.autofmt_xdate()
    fig.tight_layout()
    config.FIGURES.mkdir(parents=True, exist_ok=True)
    path = config.FIGURES / f"{user_id}_{canonical}_{start_date}_{end_date}.png"
    fig.savefig(path, dpi=110)
    plt.close(fig)
    s = df[canonical].dropna()  # Summary statistics only; the plotted series retains gaps.
    last_date = df.loc[df[canonical].notna(), "date"].iloc[-1].date().isoformat()
    return ToolResult(
        "image",
        f"Plotted {canonical} (n={len(s)} non-missing, {len(df)} dated rows): "
        f"mean {s.mean():.2f}, range [{s.min():.2f}, {s.max():.2f}], "
        f"last observed {s.iloc[-1]:.2f} {CATALOG.unit_for(canonical)} on {last_date}.",
        str(path),
    )
