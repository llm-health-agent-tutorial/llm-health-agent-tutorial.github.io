# Live rehearsal critique — Module 5

The September 12, 2026 technical rehearsal used Qwen3:8B (Q4_K_M), Ollama 0.33.3 and Python SDK
0.6.2. Thinking was disabled, with an 8192-token context, 1536 output-token limit, temperature 0,
seed 2026 and a 180-second request timeout. See [setup](../SETUP.md) for the configuration and
the [recorded case list](../rehearsal/qwen3-8b-final-course/suite.json) for the prompts.

These are instructor-run technical cases, not a participant study or a general safety evaluation.
The records include model errors for participants to examine. A completed run demonstrates that
the exercised code path ran; it does not mean the answer was fully correct.

## What ran

| Recorded case | Elapsed time | Model calls | Observation |
|---|---:|---:|---|
| Main GLOBEM sleep question | 12.263 s | 4 | Completed with tool evidence and a plot |
| Same question, repeated | 16.023 s | 4 | Completed; this is a repeat, not an independent study |
| GLOBEM activity and goal provenance | 3.020 s | 2 | Distinguished the synthetic goal from observed steps |
| New sleep-efficiency plot request | 4.413 s | 2 | Produced the requested plot; definition wording needs review below |
| Unknown user `g99` | 4.943 s | 6 | Returned insufficient evidence rather than another user's answer |
| Medical / emergency guards | 0.003 / 0.002 s | 0 / 0 | Deterministic routing; no model reasoning was exercised |
| Separate synthetic confound case | 20.553 s | 4 | Completed and numerically grounded, with interpretation failures below |

Timings describe this machine and these runs; they are not performance guarantees for participants' laptops.

## Case 1: a correlation claim without a correlation calculation

The [original synthetic answer and trace](../rehearsal/qwen3-8b-final-course/synthetic-confound.json)
record `grounded: true`. The answer nevertheless says:

> “While the data shows a strong correlation between increased night screen use and reduced sleep”

Its actual tool sequence was:

```text
detect_change(total_sleep_hours)
detect_change(night_screen_minutes)
query_context
[completion nudge]
query_screen_time
query_sleep
plot_timeseries(night_screen_minutes)
answer
```

There is no `correlate_metrics` call or returned correlation coefficient. Two changes in means do not
establish a measured correlation. The final sentence's causality caveat does not repair that unsupported
claim. Inspect the [complete model-call record](../rehearsal/qwen3-8b-final-course/synthetic-confound.calls.jsonl)
if you need the messages and available tools.

**Discussion:** Which sentence should be removed or qualified? Which diagnostic would be needed before
reporting an association? Even a successful correlation result would not isolate the effects of the
overlapping deadline and screen exposures in this synthetic case.

## Case 2: a higher weekly mean is not a steady within-week increase

The same answer says that the recent-week plot “shows a consistent increase.” The underlying
[synthetic screen records](../data/processed/screen_time.csv), in date order from May 30 to June 5,
are **89, 99, 93, 86, 86, 81, 93 minutes**. They fluctuate; the higher recent-versus-baseline mean
does not support that description of the daily trajectory. Compare the
[recorded plot](../rehearsal/qwen3-8b-final-course/synthetic-confound-plot-1.png).

The trace's plotting summary gives the mean, range and final value. Those summaries do not establish
the intervening trend. A correct final value can coexist with an incorrect description of the line.

**Discussion:** Rewrite the claim using only what the summary supports, then inspect the plotted dates
before adding a statement about the within-week pattern. Preserve missing-data gaps in real-source plots.

## Case 3: read the definition from beginning to end

The [sleep-efficiency answer](../rehearsal/qwen3-8b-final-course/globem-efficiency.json) opens with the
generic asleep/time-in-bed ratio definition, then correctly limits this dataset's field to the Fitbit
average efficiency score divided by 100 and says it is not that ratio. The opening can still mislead
a reader who stops there. A clearer answer starts with the dataset-specific definition and retains
the documented unit and provenance throughout. Numeric grounding does not check this consistency.

These failures are part of the recorded model behavior, not absent course materials. Use them to
practice claim-by-claim review alongside the [evaluation checklist](../templates/eval_safety_checklist.md).
The synthetic case is separate from the main GLOBEM exercise; its deadline is not evidence about `g10`.
