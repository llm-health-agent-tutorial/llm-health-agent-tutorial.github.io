# Pre-reading — Prototyping Your Personal LLM Health Agent

**October 12, 2026 · Shanghai · UbiComp/ISWC 2026 · 3.5 hours including a 30-minute break.**

This optional 15-minute reading introduces the concepts. Complete the installation before the
session. Intermediate Python is required; previous LLM-agent experience is not.

## The question

“How did my sleep change in the final week?” We first establish a recorded change, then ask which
explanations are supported and which require more evidence. The main case uses GLOBEM public-sample
features, with labeled synthetic supplements for software exercises. A fixed Python calculation
remains the baseline when the required calculation is already known.

## Four concepts

- **Prompt-only workflow:** the model works with supplied information. Check its claims against that
  information; tool access is not necessary for every useful summary.
- **Tool:** a Python function with a typed input schema and an inspectable result. The model requests
  a tool; application code executes it.
- **Agent loop:** select a tool → execute → observe → select another tool or answer.
- **Evaluation:** inspect the answer and trace. The minimum numeric grounding check tests numerical
  support in returned summaries. It does not establish correct metric attribution, complete factual
  support, causal validity, or clinical safety. Phrase-based safety handling can miss novel wording.

## The main dataset and a separate confound case

The default GLOBEM hybrid contains official public-sample observations plus explicitly synthetic
supplements: 10 participants and 481 feature-days. It is not the full restricted GLOBEM release.
Our main case is `g10`, with a dataset clock of `2018-06-08`. Recent/baseline means are about
5.05/6.40 h of sleep and 53.91/38.03 min of night screen. Read field provenance and missingness
before interpreting those values. A source date does not establish that sleep and screen describe
the same night. Invented heart rate, goals and events are not facts about source participants.

In M5, a separate fully synthetic case uses `u01` and a June 2026 window. Its generator makes a
deadline and screen use both affect sleep, with overlapping exposure patterns. The observation
window cannot identify their separate effects. We inspect this case manually without changing
the GLOBEM agent's profile. The generator's rules are not evidence the agent has retrieved.

The GLOBEM night-screen window is 00:00–06:00; the separate synthetic case uses 22:00–02:00.
Do not pool them as an identical measure.

## Prepare your laptop

Use Python **3.10–3.12**; **3.11 is recommended**. Install Jupyter and the project kernel.

~~~bash
git clone https://github.com/llm-health-agent-tutorial/llm-health-agent-starter.git
cd llm-health-agent-starter
bash install.sh
source .venv/bin/activate
make live-install
ha-check
~~~

For Windows, follow install.ps1 and SETUP.md. The main path uses a local, tool-capable model
through Ollama. Download the supported model and start its server before arriving; use
HA_BACKEND=ollama. An already available OpenAI or Gemini API key is an alternative, with the
corresponding backend explicitly selected. Store keys outside notebooks and shared outputs.

If setup fails, HA_BACKEND=scripted enables the offline fallback. It computes tool results using
fixed teaching decisions and supports the guided examples. It does **not** demonstrate open-ended
LLM reasoning. Record the actual backend banner, including any fallback, in your notes.

Start a fresh Python/Jupyter process before deliberately changing HA_DATA_DIR. The normal main
profile is GLOBEM; remove stale HA_DATA_DIR=data overrides from your shell or .env before launching.
M5 reads its separate synthetic tables for manual comparison without switching the agent profile.

## Session sequence

| Module | Minutes | Output |
|---|---:|---|
| 1 · Introduction | 30 | Design map and evidence boundary |
| 2 · Setup | 20 | Verified backend, data, and first tool call |
| 3 · Health tools | 45 | Retrieval, analysis and a plot preserving missing-data gaps |
| Break | 30 | Coffee and setup help |
| 4 · Agent wiring | 45 | Runnable loop and inspectable responses |
| 5 · Evaluation and safety panel | 30 | Hybrid probe results, synthetic confound comparison and checklist |
| 6 · Wrap-up | 10 | Bounded next-step research plan |

Reference notebooks support participants who need a worked example without overwriting their edits.
See [materials index](README.md), [starter setup](../SETUP.md), and
[data privacy checklist](../templates/data_privacy_checklist.md).
