# Tutorial materials

**Prototyping Your Personal LLM Health Agent**  
**October 12, 2026 · Shanghai · UbiComp/ISWC 2026**

The 3.5-hour session uses a local tool-capable LLM as its main path. A configured hosted provider
is an alternative; scripted is a clearly labelled fixed-example offline fallback.
Use Python 3.10–3.12, preferably 3.11, and complete setup before attending.

| Resource | Audience / purpose |
|---|---|
| [Pre-reading](pre_reading.md) | Participants: concepts, data tracks, and preparation |
| [Starter materials map](../MATERIALS.md) | Participants: setup, six modules, solutions, and data |
| [Notebook index](../notebooks/README.md) | Participants: learner and reference notebooks |
| [Data privacy checklist](../templates/data_privacy_checklist.md) | Participants and instructors: data access, processing, and sharing |
| [Evaluation checklist](../templates/eval_safety_checklist.md) | Participants: numeric, semantic, causal, and safety review |
| [Instructor runbook](instructor_runbook.md) | Instructors: timing, checkpoints, and rescue |
| [Panel moderator script](panel_moderator_script.md) | Moderator and speakers: 30-minute panel flow |
| [Red-team probes](red_team_probe_set.md) | Participants and panel: expected behaviour and manual assessment |
| [Live rehearsal critique](live_rehearsal_critique.md) | M5: inspect recorded model errors alongside the original answer and trace |
| [Survey specification](pre_tutorial_survey.md) | Organizers: pairing and setup triage; not a live form |
| [Panelist coordination drafts](panelist_outreach.md) | Organizers: unsent templates and logistics |
| [Identity checklist](messaging_update_checklist.md) | Maintainers: consistent dates, claims, and links |

The default [GLOBEM hybrid profile](../data/globem_hybrid/README.md) combines official public-sample
observations with labeled synthetic supplements for the main exercises. M3 implements retrieval,
analysis and visualization. M5 evaluates this hybrid agent, then examines a separate synthetic
confound case without reloading the kernel profile. Neither a numeric-check pass nor a successful
demonstration establishes complete factual, causal, or clinical validity.
