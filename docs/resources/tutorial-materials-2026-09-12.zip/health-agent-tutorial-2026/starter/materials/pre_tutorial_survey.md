# Pre-tutorial survey — organizer form specification

**Tutorial: October 12, 2026 · Shanghai.** Use responses for pairing and setup triage.
Send the form with the setup instructions approximately two weeks before the event; leave enough
time for an optional setup session. This document is a form specification, not a live survey.

## Privacy text for the form

Responses are visible only to the tutorial organizers and used for session logistics and pairing.
Do not submit personal health records, sensor exports, credentials, API keys, or identifiable
participant information. Access needs are optional; describe the accommodation needed rather than
a diagnosis. Organizers delete the response sheet after the tutorial.

## Questions

1. Name and email for setup coordination.
2. Affiliation and role.
3. Laptop operating system.
4. Python experience (1–5).
5. Jupyter experience: new / some / comfortable.
6. LLM experience: new / chat interfaces / API calls / tool-using agents.
7. Have you installed the starter with Python **3.10–3.12** and the project kernel?
   Prefer Python **3.11**; see [SETUP.md](../SETUP.md).
8. Did ha-check pass? Yes / tried but failed / not yet.
9. Which model path have you prepared?
   Local Ollama / existing hosted-provider key / scripted fallback only / need help.
10. If using Ollama, has a supported tool-capable model been downloaded and tested?
11. What backend banner appeared in your first tool call?
12. Optional setup issue. Paste a redacted error; remove keys, personal paths if sensitive, and data.
13. Prefer paired work or solo work?
14. Optional access accommodation needed.
15. One topic or question you would like to explore.

## Organizer use

Pair varied experience levels where possible, respecting solo preferences. Prioritize participants
whose local model is not ready: the primary path uses a real LLM. A scripted-only result verifies
the fixed-example fallback, not open-ended reasoning. Provide that rescue when needed, and pair
with a working-model participant for comparisons.

Do not request a full GLOBEM download or personal data. The public hybrid sample is already bundled;
complete credentialed data follow separate access and data-use conditions.
Record who has access to the response sheet and delete it after the event.
