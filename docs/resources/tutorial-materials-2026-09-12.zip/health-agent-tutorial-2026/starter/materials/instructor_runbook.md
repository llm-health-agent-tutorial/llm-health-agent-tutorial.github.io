# Instructor runbook

**October 12, 2026 · Shanghai · UbiComp/ISWC 2026 · 210 minutes including the break.**

This guide covers the six-module session. Pair it with [panel script](panel_moderator_script.md),
[pre-reading](pre_reading.md), and the [starter materials map](../MATERIALS.md).

## Roles and preparation

Assign one presenter, one timekeeper, and roaming helpers. Use the survey to pair participants
with different experience levels, respecting requests to work alone. Keep module checkpoints visible.

Before the event:
- Rehearse the full path on Python 3.10–3.12, preferably 3.11, with the project Jupyter kernel.
- Install live SDKs and download the selected tool-capable Ollama model on reliable internet.
- Test the local LLM path first. A configured hosted provider is an alternative.
- Test HA_BACKEND=scripted separately as an offline rescue. It supplies predetermined decisions,
  not open-ended LLM reasoning; never present fallback success as a live-model result.
- Have a verified reference run, reference notebooks, and offline installation resources available.
  A downloaded repository alone is not an offline dependency installer.
- Check backend banners, model identity, data profile, demo user, and date windows on every demo.

Use the default GLOBEM hybrid for M1–M4 and M6: `g10`, dataset date `2018-06-08`. It includes
observed public-sample features and labeled synthetic supplements. Follow its data card, licence,
provenance and missingness. The main sleep means are about 5.05/6.40 h and night-screen means
53.91/38.03 min (recent/baseline). Source-day alignment does not establish a same-night relationship.

M5 first evaluates this hybrid agent, then reads the separate synthetic `u01` tables directly for
manual confound analysis. It never changes `HA_DATA_DIR` or reloads configuration in the kernel.
Any deliberate profile change for another activity requires a fresh process.

## Run of show

| Segment | Minutes | Checkpoint |
|---|---:|---|
| M1 · Introduction | 30 | Explain where an agent adds value over a fixed analysis |
| M2 · Setup | 20 | Data loads; model path is identified; baseline tool call completes |
| M3 · Tools | 45 | Retrieval, analysis and plotting tasks return inspectable results |
| Break | 30 | Resolve remaining environment issues |
| M4 · Wiring | 45 | Trace shows registered tools and observations; response limits are explained |
| M5 · Panel | 30 | Record probe outcomes and one manual finding missed by the score |
| M6 · Wrap-up | 10 | One next experiment with an explicit failure criterion |

## M1–M2: verify the reasoning path

M1 produces a design map, not a deployment promise. For M2, run the preflight and activity baseline
with the selected real backend. A scripted banner means only the fallback has been verified.
Local LLM is the primary path; do not keep the whole room on scripted for convenience.

When a participant cannot run a model, switch that participant to scripted, explain its limits,
and pair them with a working-model participant for the open-ended comparison. Avoid debugging keys
during the core teaching blocks. Never collect or project API keys.

## M3: preserve the student exercise

Participants edit ha_workshop/student_tools.py: query_screen_time, detect_change and plot_timeseries.
The notebook should show a progress marker for unfinished stubs, not stop the whole class.
Check user/date filtering, units, ToolResult shape, and recent-versus-baseline computation.
For plotting, participants fill ax.plot and both axis labels. Keep the complete date grid and NaN gaps;
do not drop missing dates or interpolate. Budget 8 minutes reading, 10 retrieval, 7 analysis,
13 plotting and 7 checks within the 45-minute block.

Reference implementations live in ha_workshop/solutions/ and the solution notebooks. Prefer opening
a reference notebook over overwriting participant work. If participants intentionally copy a solution,
help them preserve their edits first; do not run blanket git checkout commands on their work.

## M4: connect and question

Participants edit ha_workshop/agent_config.py:
1. Register the needed retrieval, analysis, and visualization tools.
2. Serialize the observation using the complete ToolCall and ToolResult.
3. Append grounding and refusal clauses.

`compare_window` and the correlation diagnostic `correlate_metrics` are pre-provided in the workshop
agent; they are not extra student TODOs. The M2 baseline still provides only `compare_window`.

Inspect the activity and sleep responses and full trace for `config.DEMO_USER`. The activity goal is
synthetic even though the step counts are observed. The sleep response must preserve the distinction
between source-date comparison and same-night causation. Optional follow-ups inspect observed coverage.

## M5: separate evidence evaluation from the synthetic confound case

Use the [recorded live rehearsal critique](live_rehearsal_critique.md) to inspect the actual answer
and trace. It shows why a completed run and `grounded=True` do not establish a correct interpretation.

Evaluate the GLOBEM agent first. Then use the notebook's labeled direct table read and plots for
synthetic `u01`: deadline and screen increases co-occur, and the generator assigns both sleep effects.
The observation window cannot separate them. Caffeine is held at its previous-week level and is not
an established driver. Do not transfer these rules or events to GLOBEM participants, or imply that
the hybrid agent has retrieved a deadline. The main profile remains unchanged during this discussion.

The minimum numeric grounding check is not an all-facts validator. Check metric attribution,
time windows, omitted context, missingness, and causal language manually. Recognized sensitive
requests trigger deterministic responses once enabled; unrecognized phrasing can still fail.

## Rescue and extension

Wrong kernel → select the project kernel. Data error → verify the selected profile and its manifest.
Unavailable local model → verify SDK/server/model, then use scripted rescue if necessary.
Unfinished student edits → show the matching reference notebook, keeping the student files intact.

Finishers inspect another observed window, improve missingness reporting, or write a new probe and its expected outcome.
A probe failure is useful evidence; record it instead of quietly switching models to obtain a pass.
