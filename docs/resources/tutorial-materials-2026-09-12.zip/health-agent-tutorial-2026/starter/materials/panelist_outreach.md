# Panelist coordination — organizer drafts, not messages sent

**October 12, 2026 · Shanghai · Module 5: Evaluation & Safety, 30 minutes.**

The tutorial website lists three invited speakers: **Teng Han**, **Xin Liu**, and **Chenshu Wu**.
Use these drafts to coordinate confirmed participation and speaking roles; they are not an
instruction to send invitations or assume an exact room/time. Keep the moderator and number of
voices appropriate to a 30-minute panel.

## Coordination message template

Subject: UbiComp/ISWC tutorial panel — materials and logistics for October 12

Dear [Name],

Thank you for joining our tutorial, “Prototyping Your Personal LLM Health Agent,” on October 12
in Shanghai. The Evaluation & Safety panel is a 30-minute discussion with a short agent demo.

The main teaching path uses a local LLM; a hosted provider is an alternative. If the demonstration
needs the scripted rescue, we will label it as fixed-example behaviour rather than open-ended
model reasoning. We will examine numerical grounding, omitted evidence, causal overclaiming,
safety-classification failures, and data privacy.

The core exercises use the official public GLOBEM sample with clearly labeled synthetic supplements.
A separate fully synthetic case supports the Module 5 discussion of overlapping deadline and screen effects. We will distinguish it from the restricted full dataset.

Please find the panel script, probe set, and current slides at [shareable materials link].
No preparation slides are required for the panel itself. Our proposed topic for your contribution
is [topic, confirm with speaker]. The room and exact panel time are [confirmed logistics].

Best,
[Organizer name]

## Reminder template

Dear [Name],

A brief reminder about the October 12 tutorial panel in Shanghai.
Confirmed room/time: [details].
Moderator/demo driver: [names].
Current materials: [link].
Please let us know about any changes to your availability or presentation needs.

Best,
[Organizer name]

## Coordination checklist

- [ ] Confirm the exact room, panel time, and each speaker's role.
- [ ] Share the current [panel script](panel_moderator_script.md) and [probe set](red_team_probe_set.md).
- [ ] Explain the limit of the numeric check: it does not validate every factual or causal claim.
- [ ] Brief the separate Module 5 synthetic example correctly: deadline and screen effects overlap; caffeine is not
      an established driver.
- [ ] Keep the event date consistent across materials.
- [ ] Technical participants are directed to Python 3.10–3.12, preferably 3.11, and pre-event setup.
- [ ] Record logistical replies outside the public participant packet; do not publish private emails.
