# Tutorial identity and messaging checklist

## Canonical identity

- Short title: **Prototyping Your Personal LLM Health Agent**
- Full title: **Tutorial: From Multimodal Sensing Data to Actionable Health Insights — A Hands-on
  Guide to Prototyping Your Personal LLM Health Agent**
- Subtitle: **From Multimodal Sensing Data to Actionable Health Insights**
- Current teaching-material date: **October 12, 2026 · Shanghai · UbiComp/ISWC 2026**
- Duration: **3.5 hours including a 30-minute break**

Preserve the accepted proposal and CFP as historical camera-ready sources. Update current
participant materials, setup, slides, and website consistently. Do not restore the abandoned
“You Can Trust” title or imply clinical validation.

## Current implementation and teaching claims

- [ ] Local, tool-capable LLM through Ollama is the primary path; an existing hosted-provider key
      is an alternative.
- [ ] Scripted is described as fixed teaching decisions through the same interface, useful for
      offline rescue and reproducible controls; it does not provide open-ended LLM reasoning.
- [ ] Preparation states Python 3.10–3.12, preferably 3.11, Jupyter, live SDKs, and model download
      before the event.
- [ ] The default main exercise uses GLOBEM public-sample observations with labeled synthetic
      supplements; the separate fully synthetic case is used for the M5 confound discussion.
- [ ] M3 has three required tool implementations: retrieval, analysis and visualization.
- [ ] The hybrid public sample is distinguished from the restricted complete release.
- [ ] User, epoch, units, and night window come from the selected profile; switching profiles
      requires a fresh process or restarted kernel.
- [ ] The separate M5 synthetic deadline and screen increase overlap, so their effects are not separately
      identifiable here; caffeine is not an established driver.
- [ ] “Grounded” is explained as a minimum numerical check, not validation of every fact or causal claim.
- [ ] Deterministic safety handling is limited by recognition/classification coverage; no universal
      safety guarantee is claimed.
- [ ] All six module notebooks, reference answers, setup, data cards, and checklists have working links.
- [ ] Materials distinguish ready files from external actions still required, such as survey
      distribution, registration, exact room/time, and participant setup.

Historical published figures can retain their original captions. Newly authored examples should
avoid implying that an observational association proves a cause.
