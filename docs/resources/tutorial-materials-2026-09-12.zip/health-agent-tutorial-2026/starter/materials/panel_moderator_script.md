# Module 5 — Panel moderator script

**October 12, 2026 · Shanghai · 30 minutes.** Companion notebook: 05_eval_safety.ipynb.

Assign a moderator and a separate demo driver. Coordinate contributions with the three invited
speakers, Teng Han, Xin Liu, and Chenshu Wu. No unconfirmed speaker role or precise speaking slot
should be announced. The tutorial uses Python 3.10–3.12, preferably 3.11.

## Run of show

| Time | Activity |
|---|---|
| 00:00–02:00 | Frame evaluation as evidence about particular cases |
| 02:00–08:00 | Run the reference-agent probes; show backend and one full trace |
| 08:00–15:00 | What makes a useful, supported answer? |
| 15:00–23:00 | Separate synthetic confound case: compare and plot overlapping changes |
| 23:00–28:00 | Privacy, source permissions, and moving toward a study |
| 28:00–30:00 | Checklist and wrap-up handoff |

## Opening

“We can inspect which tools ran and whether checked numbers match returned evidence. These checks
do not establish complete factual support, causal validity, usefulness, or clinical safety. Today we
will ask what an automated pass misses.”

## Demonstration

Use the completed reference agent so results do not depend on unfinished student TODOs.
Use the prepared local LLM as the main path; a configured hosted provider is an alternative.
Show the backend, model, data profile, user, and time window. If a model fails, say so and switch
to the scripted fallback. Label its results as fixed-example/harness behaviour, not evidence of
open-ended model reasoning.

Keep the main GLOBEM profile active (`g10`, `2018-06-08`). Run the shipped safety categories and grounding questions. Show one answer, its trace, the expected
category, and the observed category. Include failures in the discussion. A deterministic response
to recognized wording does not establish coverage of unseen prompts.

## Q1: What makes a good answer?

- Which numerical claims can we independently reproduce?
- Are they attached to the right metric, person, unit, and period?
- Did the answer address the question and identify missing or contrary evidence?
- Was its uncertainty useful rather than a generic disclaimer?
- Did a refusal choose an appropriate form of help?

The minimum numeric grounding check does not replace this rubric. Even matching every checked
number cannot prove a claim's interpretation or causal correctness.

## Q2: What are we missing?

Open the [live rehearsal critique](live_rehearsal_critique.md). Compare its original synthetic answer
with the tool trace and plotted daily values: the numeric check passed despite an unsupported
correlation claim and an inaccurate within-week trend description.

Now open the notebook's **separate fully synthetic `u01` case**. It directly reads and plots the
`data/processed/` tables, leaving the hybrid agent configuration unchanged. In this simulator,
deadline is a common cause of increased screen use and
reduced sleep, while screen use has its own generated sleep effect. These changes overlap.
Their effects cannot be separated from this observational window. Caffeine is held at its
previous-week level and is not an established driver.

Ask whether an answer omits the deadline, presents association as cause, or cherry-picks a period.
Then ask which benign prompts are over-refused and which novel sensitive phrasings evade the
phrase-based detector. Distinguish medical refusal, emergency escalation, and crisis support.

The main GLOBEM hybrid has no planted version of this story. The synthetic case is a labeled manual
analysis; it is not evidence that the hybrid agent retrieved a deadline. Its observed values and synthetic
supplements must be evaluated separately; fabricated heart rate or events are not evidence about
the source participants.

## Q3: What changes when data are real?

Use [data privacy checklist](../templates/data_privacy_checklist.md).
Distinguish the publicly bundled sample from the complete credentialed release; the public sample
does not grant access to or redistribution rights over the full dataset. Keep source notices and
field provenance. Minimize any data sent to hosted providers and confirm applicable institutional
and data-use requirements before a real-data study.

## Close

“Check the evidence, examine what was omitted, and state what remains unknown.”
Ask each participant to record one manual finding missed by the automatic score, then hand off
to Module 6's extension plan. Use [probe set](red_team_probe_set.md) and the
[evaluation checklist](../templates/eval_safety_checklist.md) as take-home resources.
