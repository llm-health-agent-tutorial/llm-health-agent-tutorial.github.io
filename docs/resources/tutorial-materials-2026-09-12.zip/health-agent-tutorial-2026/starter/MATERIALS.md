# Participant and instructor material map

The session lasts 210 minutes including a 30-minute break. Each module has a starter notebook, a reference notebook under `notebooks/solutions/`, and an optional advanced exercise. The three tool implementations and agent-wiring tasks live in `ha_workshop/student_tools.py` and `ha_workshop/agent_config.py`.

| Session | Time | Material |
| --- | --- | --- |
| Preflight before the event | Self-paced | [Setup](SETUP.md), [00 preflight](notebooks/00_preflight.ipynb) |
| 1. Introduction | 30 min | [01 introduction](notebooks/01_introduction.ipynb) |
| 2. Setting up | 20 min | [02 setting up](notebooks/02_setting_up.ipynb) |
| 3. Designing health tools | 45 min | [03 designing tools](notebooks/03_designing_tools.ipynb) |
| Break | 30 min | Save work and discuss questions |
| 4. Wiring the agent | 45 min | [04 wiring](notebooks/04_wiring_the_agent.ipynb) |
| 5. Evaluation and safety panel | 30 min | [05 evaluation](notebooks/05_eval_safety.ipynb) |
| 6. Wrap-up | 10 min | [06 wrap-up](notebooks/06_wrap_up.ipynb) |

The [notebook index](notebooks/README.md) links each reference solution. The references import the completed solution modules and do not overwrite student code.

## Data

M1–M4 and M6 use the default GLOBEM hybrid (`g10`, dataset date `2018-06-08`). M3 implements retrieval, analysis and plotting within its 45-minute block. M5 first evaluates this agent, then reads separately labeled synthetic tables for a manual confound discussion without switching the kernel profile.

- [Default GLOBEM hybrid: main exercise](data/globem_hybrid/README.md), [data card](data/globem_hybrid/DATA_CARD.md), [field provenance](data/globem_hybrid/field_provenance.csv)
- [Separate synthetic M5 confound case](data/DATA_CARD.md), [schema](data/codebook.csv), [generator](data/generate_dataset.py)
- [Privacy checklist](templates/data_privacy_checklist.md)
- [Bring your own data](BRING_YOUR_OWN_DATA.md)

## Evaluation and extension

- [Evaluation and safety checklist](templates/eval_safety_checklist.md)
- [Recorded live rehearsal critique](materials/live_rehearsal_critique.md): M5 examples of errors that passed numeric grounding
- [Design map](templates/design_map.md)
- [Responsible use](RESPONSIBLE_USE.md), [SACI scaffold](SACI_SCAFFOLD.md)
- [Extension guide](EXTENDING.md), [cookbook](docs/cookbook.md), [roadmap](ROADMAP.md)

## Instructor materials

The `materials/` folder contains the runbook, pre-reading, survey, panel moderator guide, red-team prompts and communication drafts. The [slides folder](slides/) contains the editable 52-slide deck, PDF and presenter notes. Panelist-specific guest presentations remain the invited speakers' own contributions; the teaching deck provides moderator questions and exercise material.
