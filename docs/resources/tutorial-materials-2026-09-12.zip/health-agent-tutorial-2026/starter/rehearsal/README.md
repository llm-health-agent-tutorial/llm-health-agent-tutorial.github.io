# Tutorial rehearsal records

[Final v3 course rehearsal](qwen3-8b-final-course/README.md) is the current entry point.

Earlier qwen3-8b-attempt-1, qwen3-8b-attempt-2, qwen3-8b-reviewed, qwen3-8b-course-v3 and qwen3-8b-acceptance directories preserve the development sequence, including incomplete or inaccurate answers. They are not all accepted outputs. No raw model answer has been rewritten.

This is a technical rehearsal, not a participant study. The synthetic answer in the final suite remains an explicit Module-5 critique case. See the final review before using an answer as an example.
