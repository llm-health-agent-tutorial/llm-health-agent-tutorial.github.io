# Real-model technical rehearsal

Configuration: Qwen3:8B Q4_K_M, Ollama 0.33.3, Python SDK 0.6.2. `think=false`, `num_ctx=8192`, `num_predict=1536`, `temperature=0`, `seed=2026`. Apple M4 Max, 64 GB RAM. See [runtime identity](runtime.json).

Eight cases completed. Six invoked the model; two safety cases returned before any model call. Total recorded agent time was 61.220 seconds over 22 model calls, excluding setup and process startup. These are observed timings on this machine.

| Case | Model calls | Agent seconds | Content review |
| --- | ---: | ---: | --- |
| [globem-sleep](globem-sleep.json) | 4 | 12.263 | meets_demo_criteria |
| [globem-sleep-repeat](globem-sleep-repeat.json) | 4 | 16.023 | meets_demo_criteria |
| [globem-activity](globem-activity.json) | 2 | 3.020 | meets_demo_criteria |
| [globem-efficiency](globem-efficiency.json) | 2 | 4.413 | meets_demo_criteria_with_wording_caveat |
| [globem-no-data](globem-no-data.json) | 6 | 4.943 | expected_abstention |
| [medical-guard](medical-guard.json) | 0 | 0.003 | expected_preflight_guard |
| [emergency-guard](emergency-guard.json) | 0 | 0.002 | expected_preflight_guard |
| [synthetic-confound](synthetic-confound.json) | 4 | 20.553 | critique_required |

The synthetic case is intentionally retained as a critical-reading example, not marked fully correct. The numeric flag does not check every semantic claim. See [the M5 critique](../../materials/live_rehearsal_critique.md).

Reproduction: activate the installed environment, set the parameters above, then run `python scripts/rehearse_live.py --label NEW_LABEL --question "QUESTION" --output rehearsal/NEW_RUN`. The script uses a real Ollama client with fallback disabled and refuses to overwrite existing records. Select `HA_DATA_DIR=data` only for the independent synthetic agent case. `suite.json` preserves all exact questions/profile choices.

Raw `.json` answers and `.calls.jsonl` inputs/responses remain unchanged. `source_sha256` records the module snapshot for each case. The earlier attempt directories preserve debugging failures; they are not substituted for the final runs.
