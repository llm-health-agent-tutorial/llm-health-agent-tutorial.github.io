# Prototyping Your Personal LLM Health Agent

UbiComp/ISWC 2026, October 12 afternoon, Shanghai. Exact start and end times remain to be confirmed.

This 52-slide v4 edition uses plain white academic layouts, shorter titles, readable code and editable evidence charts. The GLOBEM hybrid remains the main exercise. The synthetic dataset appears separately in Module 5 as a confound case. Code, datasets and exercise requirements follow the v3 course.

- `health-agent-tutorial-2026-v4-afternoon.pptx`: editable slides with presenter notes and sources.
- `health-agent-tutorial-2026-v4-afternoon.pdf`: the same presentation as a PDF.
- `speaker-notes.md`: searchable presenter notes.
- `slides-overview.jpg`: overview of the full deck.

## Session map

| Slides | Module | Time | Companion notebook |
| --- | --- | --- | --- |
| 1–12 | Introduction and the main GLOBEM exercise | 30 min | `01_introduction.ipynb` |
| 13–18 | Environment, local model and dataset verification | 20 min | `02_setting_up.ipynb` |
| 19–27 | Retrieval, analysis and required visualization task | 45 min | `03_designing_tools.ipynb` |
| 28 | Break | 30 min | |
| 29–39 | Wiring, inspection and actual model rehearsal | 45 min | `04_wiring_the_agent.ipynb` |
| 40–49 | GLOBEM evaluation, separate synthetic case and safety panel | 30 min | `05_eval_safety.ipynb` |
| 50–52 | Wrap-up | 10 min | `06_wrap_up.ipynb` |

## Data and exercise boundaries

The main profile is `data/globem_hybrid`: 10 participants and 481 source-days from the official public sample, with labeled synthetic supplements. The shared example is `g10`, with an epoch of `2018-06-08`. Main sleep and screen charts use observed fields and show their different nonmissing counts. Source-day alignment does not imply the same night. Hybrid `sleep_efficiency` is the Fitbit average efficiency score divided by 100, not a recalculated asleep/in-bed ratio.

Participants implement `query_screen_time`, `detect_change` and `plot_timeseries` in `ha_workshop/student_tools.py`. The plotting task preserves calendar gaps and labels both axes. Module 4 registers the student-built plot. Participants continue to edit only two files, with agent configuration in `ha_workshop/agent_config.py`.

Module 5 first evaluates the GLOBEM agent, then directly reads the fully synthetic `u01` case from `data/processed` into separate variables. The active agent profile stays unchanged. The planted deadline and screen pattern is not evidence about GLOBEM participants.

Invited-speaker portraits and institutions follow the tutorial website. The deck includes the organizers’ common teaching material and panel questions, not the guests’ own talks. Source paths in notes are relative to the starter repository.

## Actual model rehearsal

Slide 39 summarizes the final Qwen3:8B rehearsal: six cases invoked the model and two cases used preflight safety checks. The repeated main sleep question took 12.26 and 16.02 seconds. The sleep-efficiency plot took 4.41 seconds, and the synthetic confound case took 20.55 seconds. The main sleep runs returned r = −0.23 and made no causal claim. The slide preserves the synthetic answer’s unsupported “strong correlation” phrase as a failure example. Successful tool execution does not establish that every statement is correct. Presenter notes record the tested settings and link to the original run records.
