#!/usr/bin/env bash
# Build a per-platform OFFLINE install pack (pre-event ops task; run on good wifi).
# Produces a wheelhouse + bundle so a cold/locked-down laptop can install with NO network.
# Run this once per target platform (macOS-arm64, macOS-x86_64, Windows, Linux).
set -euo pipefail
cd "$(dirname "$0")/.."

OUT="${1:-offline-pack-$(uname -s)-$(uname -m)}"
mkdir -p "$OUT/wheelhouse"

echo "==> downloading wheels for Python 3.11 into $OUT/wheelhouse (incl. build deps)"
# Include build-system deps (setuptools/wheel) so the editable install works fully offline.
# uv has no `pip download` command; run the real pip resolver in an isolated tool env.
if command -v uvx >/dev/null 2>&1; then
  uvx --python 3.11 --from pip pip download --python-version 3.11 --only-binary=:all: \
    -r requirements.txt "setuptools>=68" wheel -d "$OUT/wheelhouse"
else
  python3 -m pip download --python-version 3.11 --only-binary=:all: \
    -r requirements.txt "setuptools>=68" wheel -d "$OUT/wheelhouse"
fi

echo "==> copying repo essentials (code + committed data + notebooks + installers)"
python3 - "$OUT" <<'PY'
from pathlib import Path
import shutil
import sys
out = Path(sys.argv[1])
ignore = shutil.ignore_patterns('__pycache__', '*.pyc', '.ipynb_checkpoints', '.DS_Store')
for name in ('healthagent', 'ha_workshop', 'data', 'notebooks', 'templates', 'docs', 'materials', 'slides', 'rehearsal'):
    shutil.copytree(name, out / name, dirs_exist_ok=True, ignore=ignore)
for name in ('pyproject.toml', 'requirements.txt', 'uv.lock', 'install.sh', 'install.ps1', 'Makefile',
             '.env.example', 'README.md', 'SETUP.md', 'MATERIALS.md', 'RESPONSIBLE_USE.md',
             'BRING_YOUR_OWN_DATA.md', 'SACI_SCAFFOLD.md', 'EXTENDING.md', 'ROADMAP.md', 'LICENSE'):
    shutil.copy2(name, out / name)
PY

cat > "$OUT/INSTALL_OFFLINE.md" <<'EOF'
# Offline install (no network)
1. Install Python 3.11 (carry the installer on the USB stick if needed).
2. python3.11 -m venv .venv && source .venv/bin/activate   (Windows: .venv\Scripts\activate)
3. pip install --no-index --find-links wheelhouse -r requirements.txt
4. pip install --no-index --find-links wheelhouse "setuptools>=68" wheel   # build deps
5. pip install --no-index --find-links wheelhouse --no-build-isolation -e . --no-deps
6. python -m healthagent.verify
The included wheels target Python 3.11 on the platform where this pack was built.
The pack supports scripted exercises offline. The Ollama SDK is included; hosted-provider SDKs and model weights are not included.
Optionally: carry the Ollama model (`ollama pull llama3.1:8b` at home) on the USB stick too.
EOF

echo "==> done: $OUT/  (zip it onto USB sticks for the room)"
