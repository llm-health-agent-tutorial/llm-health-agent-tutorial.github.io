"""Run one real-model classroom case and preserve its unedited response and tool trace."""

from __future__ import annotations
import argparse
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
from pathlib import Path
import shutil
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--label", required=True)
parser.add_argument("--question", required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--context-tool", action="store_true")
parser.add_argument("--user", default=None, help="Override the profile demo user for a test case")
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=True)
if (args.output / (args.label + ".json")).exists() or (
    args.output / (args.label + ".calls.jsonl")
).exists():
    raise SystemExit("Use a new label or output directory; rehearsal records are not overwritten.")

from healthagent import config, data  # noqa: E402 - load the selected source tree after CLI setup

config.FIGURES = args.output / (args.label + "-figures")
from healthagent.llm.client import get_client  # noqa: E402 - load the selected source tree after CLI setup
from healthagent.llm.schemas import ToolResult  # noqa: E402 - load the selected source tree after CLI setup
from healthagent.tools.registry import tool  # noqa: E402 - load the selected source tree after CLI setup
from ha_workshop.solutions import agent_config  # noqa: E402 - load the selected source tree after CLI setup


@tool
def query_context(user_id: str, start_date: str, end_date: str) -> ToolResult:
    """Retrieve recorded context events and caffeine indicators for the selected user and source dates."""
    rows = data.load_user_metric(
        user_id, "context", ["event", "caffeine_after_6pm"], start_date, end_date
    )
    events = rows["event"].fillna("none").value_counts().to_dict()
    caffeine = int(rows["caffeine_after_6pm"].sum())
    return ToolResult(
        "table",
        f"Context over n={len(rows)} days: events={events}; caffeine_after_6pm on {caffeine} days.",
        events,
    )


real = get_client("ollama", allow_fallback=False, quiet=True)
assert real.provider == "ollama" and not real.fallback_reason
calls = []


class RecordedClient:
    provider = real.provider
    supports_force_tool = real.supports_force_tool
    fallback_reason = None

    def serialize_assistant(self, *a, **k):
        return real.serialize_assistant(*a, **k)

    def serialize_tool_result(self, *a, **k):
        return real.serialize_tool_result(*a, **k)

    def chat(self, *a, **k):
        started = time.perf_counter()
        response = real.chat(*a, **k)
        raw = response.provider_raw
        raw = raw.model_dump(mode="json") if hasattr(raw, "model_dump") else raw
        if isinstance(raw, dict) and isinstance(raw.get("message"), dict):
            raw["message"].pop("thinking", None)
        entry = {
            "turn": len(calls) + 1,
            "elapsed_seconds": round(time.perf_counter() - started, 3),
            "messages": a[0] if a else k.get("messages"),
            "tools": k.get("tools"),
            "force_tool": k.get("force_tool"),
            "text": response.text,
            "tool_calls": [asdict(t) for t in response.tool_calls],
            "raw": raw,
        }
        calls.append(entry)
        with (args.output / (args.label + ".calls.jsonl")).open("a") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        print(
            json.dumps(
                {
                    "case": args.label,
                    "turn": entry["turn"],
                    "seconds": entry["elapsed_seconds"],
                    "tools": [t.name for t in response.tool_calls],
                    "chars": len(response.text),
                }
            ),
            flush=True,
        )
        return response


if args.context_tool:
    agent_config.WORKSHOP_TOOLS = [*agent_config.WORKSHOP_TOOLS, query_context]
    agent_config.SYSTEM_PROMPT += "\nFor the synthetic confound case, retrieve query_context before discussing possible explanations. Distinguish what the observed series can establish from the generator rules."
started = time.perf_counter()
record = {
    "label": args.label,
    "question": args.question,
    "started_utc": datetime.now(timezone.utc).isoformat(),
    "dataset": config.DATASET_METADATA,
    "data_kind": config.DATA_KIND,
    "user_id": args.user or config.DEMO_USER,
    "dataset_today": config.dataset_today(),
    "backend": real.provider,
    "fallback": False,
    "model": real.model,
    "options": real.options,
    "think": real.think,
    "ollama_sdk": importlib.metadata.version("ollama"),
}
record["system_prompt_sha256"] = hashlib.sha256(agent_config.SYSTEM_PROMPT.encode()).hexdigest()
record["source_sha256"] = {
    str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
    for folder in ["healthagent", "ha_workshop"]
    for p in (ROOT / folder).rglob("*.py")
}
try:
    answer = agent_config.run(
        args.question, client=RecordedClient(), user_id=args.user or config.DEMO_USER
    )
    images = []
    for i, image in enumerate(answer.images):
        dest = args.output / f"{args.label}-plot-{i+1}.png"
        shutil.copy2(image, dest)
        images.append({"file": dest.name, "sha256": hashlib.sha256(dest.read_bytes()).hexdigest()})
    record.update(
        answer=answer.text,
        grounded=answer.grounded,
        trace=answer.trace,
        images=images,
        elapsed_seconds=round(time.perf_counter() - started, 3),
        model_calls=len(calls),
        status="completed",
    )
except Exception as exc:
    record.update(
        status="error",
        error=f"{type(exc).__name__}: {exc}",
        model_calls=len(calls),
        elapsed_seconds=round(time.perf_counter() - started, 3),
    )
    raise
finally:
    (args.output / (args.label + ".json")).write_text(
        json.dumps(record, ensure_ascii=False, indent=2) + "\n"
    )
    print(
        json.dumps(
            {
                k: record.get(k)
                for k in ["label", "status", "elapsed_seconds", "model_calls", "grounded", "error"]
            }
        ),
        flush=True,
    )
if record["status"] == "completed":
    print(record["answer"], flush=True)
