# Setup (please do this ~2 weeks before the tutorial, on good wifi)

The room has limited time and flaky wifi, so **install at home**. In the session, Module 2 is
just a quick *verification*, not a first install.

## 1. Install
```bash
git clone https://github.com/llm-health-agent-tutorial/llm-health-agent-starter.git && cd llm-health-agent-starter
bash install.sh                  # macOS/Linux
source .venv/bin/activate         # activate in this terminal after the installer exits
```
For Windows PowerShell:
```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1
.\.venv\Scripts\Activate.ps1
```
If PowerShell blocks activation, use `.\.venv\Scripts\python.exe -m healthagent.verify`
and `.\.venv\Scripts\jupyter.exe lab notebooks\` directly.

The installer uses **uv** to provision **Python 3.11** (fresh 2026 laptops often ship 3.13/3.14,
outside this project's supported Python range). If you don't have `uv`, install it from
<https://docs.astral.sh/uv/> (one line) or use conda: `conda env create -f environment.yml`,
then `conda activate health-agent` and `pip install -e .`.

**Can't install locally?** As a backup you can run the whole tutorial in the browser (no install) via
**GitHub Codespaces** or **Binder** — see *"Run in your browser"* in the [README](README.md). Local
install is still recommended; the browser options are a safety net.

## 2. Verify
```bash
ha-check
```
You should see PASS for Python, Core libraries, and Teaching dataset. The Backend row will say
`scripted` unless you set up a key/model (next).

## 3. A local model for the full LLM path
The **scripted** backend supports fixed guided exercises with no key. It does not perform open-ended LLM reasoning. For the full live
experience, the standard installer includes the Ollama SDK. Install the Ollama application and model before the event. For optional hosted providers, add their SDKs:
```bash
make live-install                       # optional hosted SDKs, plus the locked Ollama SDK
# pip users:  pip install -r requirements-live.txt
```
Then pick a backend:
- **Local model** — install [Ollama](https://ollama.com) and download the selected model on home wifi.
  The technical rehearsal used **Qwen3:8B, Q4_K_M**, Ollama **0.33.3**, and Python SDK **0.6.2**
  (the project requires SDK >=0.6). Run `ollama pull qwen3:8b` before the event and start Ollama.
  Do not download models at the venue. Confirm the model variant with `ollama show qwen3:8b`.

Use these rehearsed settings in the repository's `.env` file:
```dotenv
HA_BACKEND=ollama
OLLAMA_MODEL=qwen3:8b
OLLAMA_THINK=false
OLLAMA_NUM_CTX=8192
OLLAMA_NUM_PREDICT=1536
OLLAMA_TEMPERATURE=0
OLLAMA_SEED=2026
OLLAMA_TIMEOUT=180
```

Eight recorded cases exercised the main GLOBEM question, a repeat, activity, a new plot request,
an unknown user, two deterministic safety guards, and the separate synthetic case. The main question
took 12.263 seconds (repeat: 16.023 seconds) on the rehearsal machine. These are observed timings,
not laptop performance guarantees. The synthetic answer still contained interpretation errors despite
`grounded=True`; see [live rehearsal critique](materials/live_rehearsal_critique.md).
This was a technical rehearsal, not a participant study or a demonstration of universal safety.

If you prefer a hosted model, set `HA_BACKEND=openai` or `HA_BACKEND=gemini` plus its API key in `.env`.
Do not send credentialed GLOBEM or private participant data to a hosted provider without the required permission.

Re-run `ha-check` to confirm the active tier. If a key/model is set but the SDK is missing, it
falls back to scripted and prints the exact fix (`make live-install`).

## 4. Open the main GLOBEM exercise

The default profile is the GLOBEM public-sample hybrid (`g10`, dataset date `2018-06-08`).
Remove stale `HA_DATA_DIR=data` overrides from your shell or `.env` before starting Jupyter.
The separate synthetic case is handled inside M5 without reloading the kernel's data profile.
```bash
make lab        # or: jupyter lab notebooks/
```
Pick the **health-agent** kernel. Run `00_preflight.ipynb` top to bottom — if the last cell prints
an answer and the expected tool trace, your wiring check passed. Verify your selected real model separately before the event.

Problems? See the troubleshooting table in the [README](README.md).
