"""grounding.check: magnitude match, literal sign-flip rejection, window/date numbers ignored."""
import pytest

from healthagent.agent import grounding
from healthagent.llm.schemas import EvidenceRecord, ToolCall, ToolResult


def _ev(summary, error=False):
    # non-empty value so a non-error record reads as usable evidence (empty value == failed)
    return EvidenceRecord(ToolCall("i", "detect_change", {}),
                          ToolResult("text", summary, {"ok": True}, error=error))


SUMMARY = "total_sleep_hours down -23.9% (recent 5.69 vs baseline 7.47 hours; significant)."


def test_positive_phrasing_matches_negative_summary():
    # correct live phrasing states magnitude positively with a direction word
    assert grounding.check("your sleep dropped 24% this week", [_ev(SUMMARY)])


def test_exact_quote_grounds():
    assert grounding.check("sleep is down -23.9%", [_ev(SUMMARY)])


def test_literal_sign_flip_rejected():
    # answer claims +24 while summary is -24: a literal signed contradiction -> not grounded
    assert not grounding.check("sleep went +24% (i.e. up)", [_ev("change -24% down")])


def test_window_only_number_not_grounding():
    # "7 days" is a window count, not evidence
    assert not grounding.check("I looked at the last 7 days.", [_ev(SUMMARY)])


def test_number_absent_from_summary():
    assert not grounding.check("your sleep changed by 99 hours", [_ev(SUMMARY)])


def test_failed_evidence_never_grounds():
    assert not grounding.check("sleep down 23.9%", [_ev("tool error: boom", error=True)])


def test_one_correct_number_cannot_launder_a_fabricated_claim():
    assert not grounding.check("Sleep averaged 5.69 hours and screen use was 99999 minutes.",
                               [_ev(SUMMARY)])
    assert grounding.check("Sleep averaged 5.69 hours versus 7.47 hours at baseline.", [_ev(SUMMARY)])


def test_sentence_final_and_attached_unit_numbers_are_checked():
    for answer in ["Sleep 5.69 hours and correlation 0.99.", "Sleep 5.69h and HR 9999bpm."]:
        assert not grounding.check(answer, [_ev(SUMMARY)])
    assert grounding.check("For u01, sleep was 5.69h.", [_ev(SUMMARY)])


CORRELATION_SUMMARY = (
    "corr(sleep, screen) = -0.23: weak negative association; "
    "n=25 paired observations within 2018-05-12..2018-06-08 (28 calendar days)."
)


def test_measurement_and_supported_pair_count_and_window_can_ground_together():
    answer = "Correlation was -0.23 using 25 paired observations over a 28-day window."
    assert grounding.check(answer, [_ev(CORRELATION_SUMMARY)])
    assert grounding.check("r=-0.23, n=25 within 2018-05-12..2018-06-08.",
                           [_ev(CORRELATION_SUMMARY)])


@pytest.mark.parametrize("answer", ["n=25.", "25 paired observations.",
                                     "The window covered 28 calendar days.",
                                     "A 28-day period.", "25 observations over 28 days."])
def test_context_counts_alone_cannot_ground(answer):
    assert not grounding.check(answer, [_ev(CORRELATION_SUMMARY)])


def test_a_count_cannot_supply_the_measurement_match_on_either_side():
    assert not grounding.check("The value was 25.", [_ev("n=25 paired observations.")])
    for formatted_count in ("25", "**25**", "*25*", "`25`"):
        assert not grounding.check(f"There were {formatted_count} paired observations.",
                                   [_ev("Mean value 25; n=25 paired observations.")])


@pytest.mark.parametrize("answer", ["r=-0.23 from 99 paired observations.",
                                     "r=-0.23 over a 99-day window.",
                                     "r=-0.23 and the mean was 9999."])
def test_correct_measurement_does_not_hide_an_unsupported_count_or_value(answer):
    assert not grounding.check(answer, [_ev(CORRELATION_SUMMARY)])
