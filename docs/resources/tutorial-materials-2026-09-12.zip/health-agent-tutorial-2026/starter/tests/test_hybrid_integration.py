"""Public-sample profile must preserve origins across tools and alternate metric names."""
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def test_hybrid_tool_origins_and_cross_origin_boundaries():
    script = '''
from healthagent import config
from healthagent.tools import analysis, visualization
from healthagent.tools.registry import ToolRegistry
u=config.DEMO_USER
s,e=config.recent_window()
assert analysis.correlate_metrics(u,"total_sleep_hours","hrv_rmssd_ms").error
corr=analysis.correlate_metrics(u,"total_sleep_hours","night_screen_minutes")
assert not corr.error and corr.value["r"] == -0.23 and corr.value["n"] == 25, corr
assert "Source-day association only" in corr.summary and "not same-night evidence" in corr.summary
assert "temporal order or causation" in corr.summary
assert "n=25 paired observations within 2018-05-12..2018-06-08 (28 calendar days)" in corr.summary
assert "25 days" not in corr.summary
assert visualization.plot_two_metrics(u,"total_sleep_hours","hrv_rmssd_ms",s,e).error
registry=ToolRegistry()
registry.register(visualization.plot_timeseries)
r=registry.call("plot_timeseries",user_id=u,metric="hrv",start_date=s,end_date=e)
assert not r.error, r.summary
assert "hrv_rmssd_ms=synthetic" in r.summary, r.summary
print("profile boundaries OK")
'''
    env = {**os.environ, "HA_DATA_DIR": str(ROOT / "data/globem_hybrid"), "HA_BACKEND": "scripted"}
    result = subprocess.run([sys.executable, "-E", "-c", script], cwd=ROOT, env=env,
                            capture_output=True, text=True, timeout=90)
    assert result.returncode == 0, result.stdout + result.stderr
