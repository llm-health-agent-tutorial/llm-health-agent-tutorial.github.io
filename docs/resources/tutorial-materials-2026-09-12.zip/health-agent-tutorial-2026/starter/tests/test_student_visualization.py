"""The student plotting TODO must draw real data, retain gaps, and label its axes."""
import importlib.util
from pathlib import Path

import matplotlib.image as mpimg
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
import numpy as np
import pandas as pd
import pytest

from ha_workshop import student_tools as starter
from ha_workshop.solutions import student_tools as solution
from healthagent import config, data
from healthagent.llm.evidence import is_failed_tool_result

PLOT_EDIT = '''    ax.plot(df["date"], df[canonical], marker="o", ms=3)
    ax.set_xlabel("Date")
    ax.set_ylabel(CATALOG.unit_for(canonical))'''
PLOT_TODO = '    pass  # TODO: plot the values and set the two axis labels'


def _edited_starter(tmp_path, edit=PLOT_EDIT):
    path = tmp_path / "edited_student_tools.py"
    source = Path(starter.__file__).read_text()
    assert PLOT_TODO in source
    path.write_text(source.replace(PLOT_TODO, edit))
    spec = importlib.util.spec_from_file_location("edited_student_tools", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture
def sparse_metric(tmp_path, monkeypatch):
    # Jan 2 has an explicit null; Jan 3 has no row. Both must appear as gaps.
    frame = pd.DataFrame({"date": pd.to_datetime(["2020-01-01", "2020-01-02", "2020-01-04", "2020-01-05"]),
                          "night_screen_minutes": [10.0, np.nan, 20.0, 40.0]})
    monkeypatch.setattr(data, "load_user_metric", lambda *args, **kwargs: frame.copy())
    monkeypatch.setattr(config, "FIGURES", tmp_path / "figures")
    return frame


@pytest.mark.parametrize("implementation", ["solution", "edited_starter"])
def test_plot_contains_real_series_labels_and_missing_date_gaps(
    implementation, sparse_metric, tmp_path, monkeypatch
):
    module = solution if implementation == "solution" else _edited_starter(tmp_path)
    captured = []
    original_savefig = Figure.savefig

    def capture(fig, *args, **kwargs):
        ax = fig.axes[0]
        assert len(ax.lines) == 1
        captured.append((ax.lines[0].get_xdata(), ax.lines[0].get_ydata(),
                         ax.get_xlabel(), ax.get_ylabel()))
        return original_savefig(fig, *args, **kwargs)

    monkeypatch.setattr(Figure, "savefig", capture)
    result = module.plot_timeseries("participant-1", "night_screen_minutes", "2020-01-01", "2020-01-05")
    assert result.kind == "image" and not result.error
    assert len(captured) == 1
    x, y, xlabel, ylabel = captured[0]
    np.testing.assert_array_equal(x, pd.date_range("2020-01-01", "2020-01-05").to_numpy())
    np.testing.assert_allclose(y, [10.0, np.nan, np.nan, 20.0, 40.0], equal_nan=True)
    assert xlabel == "Date" and ylabel == "minutes"
    assert "n=3 non-missing, 5 dated rows" in result.summary
    assert "mean 23.33" in result.summary and "last observed 40.00" in result.summary
    pixels = mpimg.imread(result.value)
    assert pixels.shape[:2] == (330, 770)
    # Visible blue data pixels, in addition to the series/label assertions above.
    assert np.count_nonzero((pixels[:, :, 2] > pixels[:, :, 0] + 0.2)
                            & (pixels[:, :, 2] > pixels[:, :, 1] + 0.1)) > 20


@pytest.mark.parametrize("implementation", ["starter", "solution"])
@pytest.mark.parametrize("values", [[], [np.nan, np.nan]])
def test_empty_or_all_missing_data_is_an_error(implementation, values, tmp_path, monkeypatch):
    frame = pd.DataFrame({"date": pd.date_range("2020-01-01", periods=len(values)),
                          "night_screen_minutes": values})
    monkeypatch.setattr(data, "load_user_metric", lambda *args, **kwargs: frame.copy())
    monkeypatch.setattr(config, "FIGURES", tmp_path / "figures")
    module = starter if implementation == "starter" else solution
    result = module.plot_timeseries("participant-1", "night_screen_minutes", "2020-01-01", "2020-01-05")
    assert result.error and is_failed_tool_result(result)
    assert not list(tmp_path.rglob("*.png"))


@pytest.mark.parametrize("partial_edit", [None, '    ax.plot(df["date"], df[canonical])'])
def test_unfilled_plot_or_labels_fail_safe_without_leaking_a_figure(
    partial_edit, sparse_metric, tmp_path
):
    module = starter if partial_edit is None else _edited_starter(tmp_path, partial_edit)
    before = plt.get_fignums()
    result = module.plot_timeseries("participant-1", "night_screen_minutes", "2020-01-01", "2020-01-05")
    assert is_failed_tool_result(result) and result.kind == "text"
    assert plt.get_fignums() == before
    assert not list(tmp_path.rglob("*.png"))
