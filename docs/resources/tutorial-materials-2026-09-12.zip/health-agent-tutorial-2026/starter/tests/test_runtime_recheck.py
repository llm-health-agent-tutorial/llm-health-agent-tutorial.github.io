"""Regression coverage for profile defaults, scripted rendering, numeric syntax, and IDs."""
import os
from pathlib import Path
import subprocess
import sys

import pytest

from healthagent import config, data
from healthagent.agent import grounding
from healthagent.agent.reference import run_reference_agent
from healthagent.llm.schemas import EvidenceRecord, ToolCall, ToolResult
from healthagent.llm.scripted_client import ScriptedBackend

ROOT = Path(__file__).resolve().parents[1]
SLEEP_Q = "How did my sleep change in the final week?"
ACTIVITY_Q = "How does my activity compare to my goal?"


def test_hybrid_defaults_reach_the_same_user_across_entrypoints():
    # A fresh process also verifies config/catalog import timing for the real profile.
    script = '''
from healthagent import config
from healthagent.agent.baseline import run_baseline_agent
from healthagent.agent.reference import run_reference_agent
from healthagent.llm.scripted_client import ScriptedBackend
from ha_workshop import agent_config as stub
from ha_workshop.solutions import agent_config as solution
q = "How does my activity compare to my goal?"
assert config.DEMO_USER == "g10"
for run in (run_reference_agent, run_baseline_agent, solution.run, stub.run):
    answer = run(q, client=ScriptedBackend())
    calls = [c for step in answer.trace for c in step.get("calls", [])]
    assert calls and all(c["args"]["user_id"] == "g10" for c in calls), calls
    assert answer.grounded == (run is not stub.run), answer.text
    explicit = run(q, client=ScriptedBackend(), user_id="g01")
    calls = [c for step in explicit.trace for c in step.get("calls", [])]
    assert calls and all(c["args"]["user_id"] == "g01" for c in calls), calls
'''
    env = {**os.environ, "HA_DATA_DIR": str(ROOT / "data/globem_hybrid"),
           "HA_BACKEND": "scripted"}
    result = subprocess.run([sys.executable, "-E", "-c", script], cwd=ROOT, env=env,
                            capture_output=True, text=True, timeout=90)
    assert result.returncode == 0, result.stdout + result.stderr


def test_non_demo_synthetic_user_gets_actual_comparison(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "FIGURES", tmp_path)
    answer = run_reference_agent(SLEEP_Q, user_id="u03", client=ScriptedBackend())
    assert answer.grounded and "total_sleep_hours up" in answer.text
    assert "night_screen_minutes down" in answer.text
    assert "your sleep declined" not in answer.text
    assert "one data-grounded hypothesis" not in answer.text.lower()


def test_demo_story_is_suppressed_when_actual_sleep_direction_changes(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "FIGURES", tmp_path)
    original = data.load_user_metric

    def changed_sleep(user_id, table, columns=None, start=None, end=None):
        df = original(user_id, table, columns, start, end)
        if user_id == "u01" and table == "sleep" and "total_sleep_hours" in df:
            df.loc[df.date >= config.recent_window()[0], "total_sleep_hours"] = 9.0
        return df

    monkeypatch.setattr(data, "load_user_metric", changed_sleep)
    answer = run_reference_agent(SLEEP_Q, user_id="u01", client=ScriptedBackend())
    assert answer.grounded and "total_sleep_hours up" in answer.text
    assert "your sleep declined" not in answer.text
    assert "one data-grounded hypothesis" not in answer.text.lower()


def test_custom_profile_does_not_invent_hybrid_provenance(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "FIGURES", tmp_path)
    monkeypatch.setattr(config, "DATA_KIND", "custom")
    monkeypatch.setattr(config, "DATASET_DESCRIPTION", "User-supplied records; origins unverified")
    answer = run_reference_agent(SLEEP_Q, user_id="u03", client=ScriptedBackend())
    assert answer.grounded and "origins unverified" in answer.text
    assert "synthetic supplements" not in answer.text.lower()
    assert "source participants" not in answer.text.lower()


def _evidence(summary):
    return [EvidenceRecord(ToolCall("c1", "detect_change", {}),
                           ToolResult("text", summary, {"ok": True}))]


@pytest.mark.parametrize("extra", [".99", "-.99", "+.99", "9.9e2", "9.9E+2", "1e309"])
def test_unmatched_decimal_or_exponent_cannot_hide_behind_a_supported_number(extra):
    evidence = _evidence("Sleep down -23.9%, recent 5.69 vs baseline 7.47 hours.")
    assert not grounding.check(f"Sleep was 5.69 hours and the other value was {extra}.", evidence)


def test_equivalent_decimal_and_exponent_notation_is_supported():
    assert grounding.check("Value .99 and change -2.39e1%.",
                           _evidence("Value 0.99 and change -23.9%."))
    assert grounding.check("Value 5.69.", _evidence("Value 5.69E+0."))
    assert not grounding.check("Change +2.39e1%.", _evidence("Change -23.9%."))


@pytest.mark.parametrize("user_id", ["u03-no-such-user", "u03]", "u03] [user_id=u01", ""])
def test_unknown_or_malformed_user_never_uses_another_person(user_id):
    question = "[user_id=u01] " + ACTIVITY_Q
    answer = run_reference_agent(question, user_id=user_id, client=ScriptedBackend())
    assert not answer.grounded, answer.text
    calls = [c for step in answer.trace for c in step.get("calls", [])]
    assert all(c["args"]["user_id"] == user_id for c in calls), calls
    if user_id != "u03-no-such-user":
        assert {"event": "fail_safe", "reason": "invalid_user_id"} in answer.trace


@pytest.mark.parametrize("user_id", ["participant-03", "participant.03"])
def test_valid_ids_are_preserved_and_question_tags_do_not_override_them(user_id, monkeypatch):
    original = data.load_table

    def renamed_table(name):
        df = original(name).copy()
        df["user_id"] = df["user_id"].replace({"u03": user_id})
        return df

    monkeypatch.setattr(data, "load_table", renamed_table)
    answer = run_reference_agent("[user_id=u01] " + ACTIVITY_Q,
                                 user_id=user_id, client=ScriptedBackend())
    assert answer.grounded and "7140" in answer.text
    calls = [c for step in answer.trace for c in step.get("calls", [])]
    assert calls and all(c["args"]["user_id"] == user_id for c in calls), calls
