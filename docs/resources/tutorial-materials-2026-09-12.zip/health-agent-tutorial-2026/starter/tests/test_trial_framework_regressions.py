"""Offline reproductions of two framework failures found in real GLOBEM trials."""
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def test_real_globem_activity_window_and_efficiency_plot_can_finalize(tmp_path):
    script = '''
from pathlib import Path
from healthagent import config, data
from healthagent.agent import grounding
from healthagent.llm.client import LLMClient
from healthagent.llm.schemas import ChatResponse, ToolCall, EvidenceRecord
from ha_workshop.solutions import agent_config
import sys
config.FIGURES = Path(sys.argv[1])
registry = agent_config.make_registry()
result = registry.call("compare_window", user_id="g10", recent_days=7)
assert result.value["recent_window"] == ["2018-06-02", "2018-06-08"]
assert result.value["recent_days"] == 7 and result.value["recent_n"] == 7
assert "7 calendar days; n=7 non-missing" in result.summary
recorded_numbers = (
    "Your recent average is 21,993 steps, 174.9% above the goal of 8,000 steps. "
    "This comparison is based on the past 7 days ending on 2018-06-08."
)
evidence = [EvidenceRecord(ToolCall("activity", "compare_window", {"recent_days": 7}), result)]
assert grounding.check(recorded_numbers, evidence)
# Cover actual missingness and a nondefault requested window, not just the demo's complete week.
for user_id, days in [("g03", 7), ("g10", 14)]:
    result = registry.call("compare_window", user_id=user_id, recent_days=days)
    start, end = result.value["recent_window"]
    observed = data.load_user_metric(user_id, "steps", ["steps"], start, end)["steps"].count()
    assert result.value["recent_n"] == observed and result.value["recent_days"] == days
    assert f"{days} calendar days; n={observed} non-missing" in result.summary

class ReplayCorrectPlot(LLMClient):
    provider = "fake"
    calls = 0
    def chat(self, messages, tools=None, *, force_tool=None):
        self.calls += 1
        if self.calls == 1:
            return ChatResponse("", [ToolCall("plot", "plot_timeseries", {
                "user_id": "g10", "metric": "sleep_efficiency",
                "start_date": "2018-05-12", "end_date": "2018-06-08",
            })])
        return ChatResponse("The observed sleep_efficiency score averaged 0.93.", [])
client = ReplayCorrectPlot()
answer = agent_config.run(
    "Plot my sleep_efficiency score over the last 28 days. Explain what this measure means "
    "and whether it is the fraction of time in bed spent asleep.", client=client,
)
assert answer.grounded and client.calls == 2, answer.trace
assert len(answer.images) == 1 and Path(answer.images[0]).is_file()
assert not any(t.get("event") in {"nudge", "fail_safe"} for t in answer.trace)
calls = [c for t in answer.trace for c in t.get("calls", [])]
assert len(calls) == 1 and calls[0]["args"]["metric"] == "sleep_efficiency"
'''
    env = {**os.environ, "HA_DATA_DIR": str(ROOT / "data/globem_hybrid"), "HA_BACKEND": "scripted"}
    result = subprocess.run([sys.executable, "-E", "-c", script, str(tmp_path)],
                            cwd=ROOT, env=env, capture_output=True, text=True, timeout=90)
    assert result.returncode == 0, result.stdout + result.stderr
