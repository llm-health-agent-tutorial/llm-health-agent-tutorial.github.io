"""Check source-backed semantic counterexamples, not the adapter's mapping dict."""
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

PROFILE = Path(__file__).resolve().parents[1] / "data" / "globem_hybrid"


def test_source_files_match_independently_verified_official_git_objects():
    # Verified against UW-EXP/GLOBEM's GitHub tree API on 2026-09-12 at commit
    # 4f140fc5290dc97204298cca28b956165aa0a29f. Do not regenerate from the bundle.
    expected = {
        "DATA_README.md": "15ab17182badafc6de462445770ebea3e9676561",
        "INS-W-sample_1/FeatureData/location.csv": "271c21f132f773ba35b1e4180eb41803d9852574",
        "INS-W-sample_1/FeatureData/screen.csv": "ab1a457533b90a301766f25ea07c3826ba5d4c45",
        "INS-W-sample_1/FeatureData/sleep.csv": "ae25602c54213d903d99475f2cf6ba8a75ee48bb",
        "INS-W-sample_1/FeatureData/steps.csv": "3424285358cdb3a9919f1d112fa3d39c1d4a88b6",
        "INS-W-sample_1/ParticipantsInfoData/platform.csv": "56f3941a53a77be15a30ecd17da8935890fda47a",
        "INS-W-sample_1/SurveyData/ema.csv": "a8fb6fbf837917cb9d4ad2d621ad6b8b8d21ced0",
        "LICENSE": "f49a4e16e68b128803cc2dcea614603632b04eac",
        "UPSTREAM_README.md": "e04c4b0830bd1a453fb6ceadb316ffa5feae0a05",
    }
    for relative, expected_sha in expected.items():
        payload = (PROFILE / "source" / relative).read_bytes()
        git_blob = b"blob " + str(len(payload)).encode() + b"\0" + payload
        assert hashlib.sha1(git_blob).hexdigest() == expected_sha, relative


def test_sleep_source_day_and_efficiency_counterexamples_are_preserved():
    sleep = pd.read_parquet(PROFILE / "processed" / "sleep.parquet").set_index(["source_pid", "date"])
    first = sleep.loc[("INS-W_004", "2018-04-30")]
    following = sleep.loc[("INS-W_004", "2018-05-01")]
    assert first.total_sleep_hours == pytest.approx(486 / 60)
    assert first.sleep_onset_hhmm == pytest.approx(1483 / 60)
    assert first.wake_hhmm == pytest.approx(493.5 / 60)
    assert following.wake_hhmm == pytest.approx(550.5 / 60)
    assert first.sleep_onset_hhmm > 24
    # The next row's wake fits 507 source in-bed minutes, within source rounding;
    # the same row's wake does not. Preserve this counterexample, not a blind shift.
    next_interval = (24 + following.wake_hhmm - first.sleep_onset_hhmm) * 60
    same_interval = (24 + first.wake_hhmm - first.sleep_onset_hhmm) * 60
    assert abs(next_interval - 507) < 1
    assert abs(same_interval - 507) > 50

    row = sleep.loc[("INS-W_004", "2018-05-13")]
    assert row.sleep_efficiency == pytest.approx(0.95)
    assert row.total_sleep_hours == pytest.approx(421 / 60)
    assert abs(row.sleep_efficiency - 421 / 461) > 0.03
    metadata = json.loads((PROFILE / "dataset_metadata.json").read_text())
    note = metadata["time_alignment_note"]
    assert all(term in note for term in ("different nights", "exceed 24", "source-day", "not same-night", "00:00-06:00"))


def test_social_minutes_are_conditional_synthetic_values_with_parent_missingness():
    screen = pd.read_parquet(PROFILE / "processed" / "screen_time.parquet")
    total, social = screen.total_screen_minutes, screen.social_app_minutes
    assert total.isna().any() and total.notna().any()
    assert social.isna().equals(total.isna())
    assert social.dropna().ge(0).all()
    assert social[total.notna()].le(total.dropna()).all()
    assert np.equal(social.dropna(), np.floor(social.dropna())).all()
    # Previously this day incorrectly had 71 synthetic minutes inside 9.901 total.
    example = screen.loc[(screen.user_id == "g01") & (screen.date == "2018-06-04")].iloc[0]
    assert example.social_app_minutes <= example.total_screen_minutes < 10
    provenance = pd.read_csv(PROFILE / "field_provenance.csv").set_index(["table", "metric"])
    field = provenance.loc[("screen_time", "social_app_minutes")]
    assert field.origin == "synthetic"
    assert field.source_column == "screen_time.total_screen_minutes"
    assert "Conditional" in field.notes and "constructed" in field.notes
    assert "independent" not in field.transformation


def test_codebook_and_provenance_expose_measurement_boundaries():
    codebook = pd.read_csv(PROFILE / "codebook.csv").set_index("metric")
    assert codebook.loc["sleep_efficiency", "unit"] == "score_0_1"
    expected_terms = {
        "sleep_efficiency": ("score divided by 100", "not a recalculated"),
        "sleep_onset_hhmm": ("exceed 24", "not aligned"),
        "wake_hhmm": ("preceding", "unlike"),
        "total_screen_minutes": ("unlock episodes",),
        "pickups": ("unlock episodes", "not physical"),
        "active_minutes": ("step-count threshold", "not exercise"),
        "sedentary_minutes": ("sleep/non-wear", "not measured waking"),
        "num_places_visited": ("clusters", "imputed"),
    }
    provenance = pd.read_csv(PROFILE / "field_provenance.csv").set_index("metric")
    for metric, terms in expected_terms.items():
        assert all(term in codebook.loc[metric, "description"] for term in terms), metric
        assert all(term in provenance.loc[metric, "notes"] for term in terms), metric
    steps = pd.read_parquet(PROFILE / "processed" / "steps.parquet")
    assert (steps.active_minutes + steps.sedentary_minutes).dropna().eq(1440).all()
    location = pd.read_parquet(PROFILE / "processed" / "location.parquet")
    assert not location.is_imputed.any()
    flags = pd.read_csv(PROFILE / "field_provenance.csv").set_index(["table", "metric"])
    assert "upstream" in flags.loc[("location", "is_imputed"), "notes"]
    assert "imputed GPS" in flags.loc[("location", "is_imputed"), "notes"]
