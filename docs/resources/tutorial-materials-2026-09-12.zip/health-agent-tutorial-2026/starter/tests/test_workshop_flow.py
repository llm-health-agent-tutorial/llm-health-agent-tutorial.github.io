"""Exercise the REAL participant path, not just the solution files:
copy ha_workshop to a temp dir, apply the *minimal expected edits* to the stubs, then run the
sleep question in a FRESH interpreter (≈ a fresh notebook kernel). Asserts that the minimal
edits are sufficient, and that the untouched stub fails safe.
"""
import os
import shutil
import subprocess
import sys
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _apply_minimal_edits(ws: Path, *, fill_plot: bool = True) -> None:
    st = ws / "student_tools.py"
    s = st.read_text()
    # query_screen_time: replace the stub return with the 3-line body
    s = s.replace(
        '    return ToolResult("text", TODO_SENTINEL, {})\n    # === END TODO-M3 ===',
        '    df = data.load_user_metric(user_id, "screen_time",\n'
        '                               ["total_screen_minutes", "night_screen_minutes"], start_date, end_date)\n'
        '    rows = df.assign(date=df["date"].dt.strftime("%Y-%m-%d")).to_dict("records")\n'
        '    return ToolResult("table", f"{len(df)} days: mean night screen "\n'
        '                      f"{round(df[\'night_screen_minutes\'].mean(),1)} min.", rows)\n'
        '    # === END TODO-M3 ===',
        1,
    )
    # detect_change: fill the two means
    s = s.replace("    recent_mean = None    # TODO: float(recent.mean())",
                  "    recent_mean = float(recent.mean())")
    s = s.replace("    baseline_mean = None  # TODO: float(base.mean())",
                  "    baseline_mean = float(base.mean())")
    if fill_plot:
        s = s.replace(
            '    pass  # TODO: plot the values and set the two axis labels',
            '    ax.plot(df["date"], df[canonical], marker="o", ms=3)\n'
            '    ax.set_xlabel("Date")\n'
            '    ax.set_ylabel(CATALOG.unit_for(canonical))',
        )
    st.write_text(s)

    cfg = ws / "agent_config.py"
    c = cfg.read_text()
    c = c.replace(
        "WORKSHOP_TOOLS: list = [\n    # TODO: list the four tools here\n]",
        "WORKSHOP_TOOLS: list = [retrieval.query_sleep, student_tools.query_screen_time,\n"
        "                        student_tools.detect_change, student_tools.plot_timeseries]",
    )
    c = c.replace(
        '    return client.serialize_tool_result(tool_call, ToolResult("text", OBSERVATION_NOT_ATTACHED, {}))',
        "    return client.serialize_tool_result(tool_call, result)",
    )
    c = c.replace(
        "SYSTEM_PROMPT = BASE_SYSTEM\n# === END TODO-3 ===",
        "from healthagent.agent.prompts import GROUNDING_CLAUSE, REFUSAL_CLAUSE\n"
        "SYSTEM_PROMPT = BASE_SYSTEM + '\\n' + GROUNDING_CLAUSE + '\\n' + REFUSAL_CLAUSE\n# === END TODO-3 ===",
    )
    cfg.write_text(c)


_RUN = textwrap.dedent("""
    import sys
    sys.path[:0] = [sys.argv[1], sys.argv[2]]  # edited workshop, then this repository
    import numpy as np
    import pandas as pd
    import matplotlib.image as mpimg
    from matplotlib.figure import Figure
    from healthagent import config, data
    from healthagent.llm.client import get_client
    from ha_workshop import agent_config as cfg
    checked_plots = []
    savefig = Figure.savefig
    def check_plot(fig, *args, **kwargs):
        ax = fig.axes[0]
        start, end = config.recent_window()
        expected = data.load_user_metric(config.DEMO_USER, "screen_time",
                                         ["night_screen_minutes"], start, end)
        expected = expected.set_index("date").reindex(pd.date_range(start, end))
        assert ax.get_xlabel() == "Date" and ax.get_ylabel() == "minutes"
        np.testing.assert_array_equal(ax.lines[0].get_xdata(), expected.index.to_numpy())
        np.testing.assert_allclose(ax.lines[0].get_ydata(), expected.night_screen_minutes,
                                   equal_nan=True)
        checked_plots.append(True)
        return savefig(fig, *args, **kwargs)
    Figure.savefig = check_plot
    c = get_client("scripted", quiet=True)
    a = cfg.run("How did my sleep change in the final week?", client=c)
    for image in a.images:
        pixels = mpimg.imread(image)
        assert pixels.shape[:2] == (330, 770)
        assert np.count_nonzero((pixels[:, :, 2] > pixels[:, :, 0] + 0.2)
                                 & (pixels[:, :, 2] > pixels[:, :, 1] + 0.1)) > 20
    assert len(a.images) == len(checked_plots)
    print("PLOTS_VERIFIED", len(checked_plots))
    print("GROUNDED", a.grounded)
    print("TEXT", a.text)
""")

def _run_in_fresh_process(tmpdir: Path, *, profile: str = "globem_hybrid") -> str:
    # Each dataset profile is explicit; cwd and the caller's HA_DATA_DIR cannot change it.
    env = {**os.environ, "HA_BACKEND": "scripted",
           "HA_DATA_DIR": str(ROOT / "data" / profile if profile != "synthetic" else ROOT / "data")}
    out = subprocess.run(
        [sys.executable, "-E", "-c", _RUN, str(tmpdir), str(ROOT)],
        capture_output=True, text=True, cwd=str(tmpdir), env=env,
    )
    assert out.returncode == 0, out.stderr
    return out.stdout


def test_minimal_edits_make_sleep_grounded(tmp_path):
    ws = tmp_path / "ha_workshop"
    shutil.copytree(ROOT / "ha_workshop", ws)
    _apply_minimal_edits(ws)
    output = _run_in_fresh_process(tmp_path)
    assert "GROUNDED True" in output
    assert "PLOTS_VERIFIED 1" in output
    assert "total_sleep_hours=observed" in output
    assert "one data-grounded hypothesis" not in output.lower()


def test_untouched_stub_fails_safe(tmp_path):
    ws = tmp_path / "ha_workshop"
    shutil.copytree(ROOT / "ha_workshop", ws)  # no edits
    output = _run_in_fresh_process(tmp_path)
    assert "GROUNDED False" in output
    assert "could not gather enough evidence" in output.lower()


def test_all_other_edits_cannot_hide_an_unfilled_plot(tmp_path):
    ws = tmp_path / "ha_workshop"
    shutil.copytree(ROOT / "ha_workshop", ws)
    _apply_minimal_edits(ws, fill_plot=False)
    output = _run_in_fresh_process(tmp_path)
    assert "GROUNDED False" in output
    assert "PLOTS_VERIFIED 0" in output
    assert "could not gather enough evidence" in output.lower()


def test_completed_edits_can_run_the_explicit_synthetic_profile(tmp_path):
    ws = tmp_path / "ha_workshop"
    shutil.copytree(ROOT / "ha_workshop", ws)
    _apply_minimal_edits(ws)
    output = _run_in_fresh_process(tmp_path, profile="synthetic")
    assert "GROUNDED True" in output and "PLOTS_VERIFIED 1" in output
    assert "one data-grounded hypothesis" in output.lower()
