"""Course defaults and local model request settings are observable contracts."""

import json
import os
from pathlib import Path
import subprocess
import sys

import pytest

ROOT = Path(__file__).resolve().parents[1]


def test_fresh_process_defaults_to_globem_mainline():
    env = {k: v for k, v in os.environ.items() if k != "HA_DATA_DIR"}
    code = """
import json
import dotenv
dotenv.load_dotenv=lambda *a,**k:None
from healthagent import config
from healthagent.tools.builtin import compare_window
print(json.dumps([config.DATA_KIND,config.DEMO_USER,config.dataset_today(),compare_window().error]))
"""
    p = subprocess.run(
        [sys.executable, "-E", "-c", code],
        cwd=ROOT,
        env=env,
        text=True,
        capture_output=True,
        check=True,
    )
    assert json.loads(p.stdout.strip().splitlines()[-1]) == ["hybrid", "g10", "2018-06-08", False]


def test_ollama_options_and_response_metadata(monkeypatch):
    ollama = pytest.importorskip("ollama")
    captured = {}

    class Client:
        def __init__(self, **kwargs):
            captured["client"] = kwargs

        def show(self, model):
            return {}

        def chat(self, model, messages, tools, *, think=None, options=None):
            captured.update(think=think, options=options, model=model)
            return {"message": {"content": "done"}, "eval_count": 4, "model": model}

    monkeypatch.setattr(ollama, "Client", Client)
    for key, value in {
        "OLLAMA_MODEL": "qwen3:8b",
        "OLLAMA_THINK": "false",
        "OLLAMA_NUM_CTX": "8192",
        "OLLAMA_NUM_PREDICT": "1536",
        "OLLAMA_TEMPERATURE": "0",
        "OLLAMA_SEED": "2026",
    }.items():
        monkeypatch.setenv(key, value)
    from healthagent.llm.ollama_client import OllamaBackend

    response = OllamaBackend().chat([{"role": "user", "content": "hello"}])
    assert captured["think"] is False
    assert captured["options"] == {
        "num_ctx": 8192,
        "num_predict": 1536,
        "temperature": 0.0,
        "seed": 2026,
    }
    assert response.provider_raw["eval_count"] == 4
    assert response.text == "done"
