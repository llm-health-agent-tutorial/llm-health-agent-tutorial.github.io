"""live_policy: intent detection, alias resolution, SIGNATURE matching (metric + date window),
missing vs unavailable, failed-then-success, and unknown-intent (never gated). No network."""
import pytest

from healthagent.agent import live_policy as LP
from healthagent.agent.live_policy import completion_check, requirements_for
from healthagent.llm.schemas import EvidenceRecord, ToolCall, ToolResult

R0, R1 = LP._R0, LP._R1
ALL = ["query_screen_time", "query_sleep", "detect_change", "plot_timeseries", "compare_window"]


def _ev(name, args, ok=True):
    # non-empty value on the happy path; an empty value is (correctly) treated as failed evidence
    res = ToolResult("text", "summary" if ok else "tool error", {"ok": True} if ok else {}, error=not ok)
    return EvidenceRecord(ToolCall("id", name, args), res)


def test_intent_detection():
    assert requirements_for("why have I been sleeping poorly") is LP.SLEEP_REQS
    assert requirements_for("how does my activity compare to my goal") is LP.ACTIVITY_REQS
    assert requirements_for("what's the weather like") == []  # unknown -> no requirements


def test_unknown_intent_never_gated():
    res = completion_check("tell me a joke", [], ALL)
    assert not res.missing and not res.unavailable  # final answer allowed


def _full_sleep_evidence():
    return [
        _ev("query_screen_time", {"user_id": "u01", "start_date": R0, "end_date": R1}),
        _ev("query_sleep", {"user_id": "u01", "start_date": R0, "end_date": R1}),
        _ev("detect_change", {"user_id": "u01", "metric": "night_screen_minutes"}),
        _ev("detect_change", {"user_id": "u01", "metric": "total_sleep_hours"}),
        _ev("plot_timeseries", {"user_id": "u01", "metric": "night_screen_minutes", "start_date": R0, "end_date": R1}),
    ]


def test_full_signatures_satisfied():
    res = completion_check("why poor sleep", _full_sleep_evidence(), ALL)
    assert not res.missing and not res.unavailable


def test_alias_resolution_in_signature():
    ev = _full_sleep_evidence()
    ev[2] = _ev("detect_change", {"user_id": "u01", "metric": "night_screen"})  # alias of night_screen_minutes
    res = completion_check("why poor sleep", ev, ALL)
    assert not res.missing  # alias resolves -> satisfied


def test_wrong_metric_not_satisfied():
    ev = _full_sleep_evidence()
    ev[3] = _ev("detect_change", {"user_id": "u01", "metric": "steps"})  # wrong metric for the sleep req
    res = completion_check("why poor sleep", ev, ALL)
    assert any(r.tool_name == "detect_change" for r in res.missing)


def test_wrong_window_not_satisfied():
    ev = _full_sleep_evidence()
    ev[1] = _ev("query_sleep", {"user_id": "u01", "start_date": "2026-01-01", "end_date": "2026-01-07"})
    res = completion_check("why poor sleep", ev, ALL)
    assert any(r.tool_name == "query_sleep" for r in res.missing)


def test_missing_vs_unavailable():
    # plot_timeseries NOT registered -> unavailable; detect_change registered but absent -> missing
    avail = ["query_screen_time", "query_sleep", "detect_change", "compare_window"]
    ev = [_ev("query_screen_time", {"user_id": "u01", "start_date": R0, "end_date": R1}),
          _ev("query_sleep", {"user_id": "u01", "start_date": R0, "end_date": R1})]
    res = completion_check("why poor sleep", ev, avail)
    assert any(r.tool_name == "detect_change" for r in res.missing)
    assert any(r.tool_name == "plot_timeseries" for r in res.unavailable)


def test_failed_then_success():
    ev = _full_sleep_evidence()
    # an earlier FAILED detect_change(night) then a later SUCCESS -> satisfied
    ev.insert(2, _ev("detect_change", {"user_id": "u01", "metric": "night_screen_minutes"}, ok=False))
    res = completion_check("why poor sleep", ev, ALL)
    assert not res.missing


@pytest.mark.parametrize("question", ["Why is sleep worse?", "Explain my sleep change",
                                      "Is sleep correlated with screen use?",
                                      "Is sleep associated with screen use?",
                                      "Are sleep and screen use related?"])
def test_registered_correlation_is_required_for_explanatory_sleep_questions(question):
    result = completion_check(question, _full_sleep_evidence(), ALL + ["correlate_metrics"])
    assert [r.tool_name for r in result.missing] == ["correlate_metrics"]
    assert not result.unavailable
    assert len(LP.SLEEP_REQS) == 5  # The generic sleep contract remains unchanged.


@pytest.mark.parametrize("args, ok, satisfied", [
    ({"metric_a": "sleep", "metric_b": "night_screen"}, True, True),
    ({"metric_a": "night_screen_minutes", "metric_b": "total_sleep_hours",
      "recent_days": 7, "baseline_days": 21}, True, True),
    ({"metric_a": "steps", "metric_b": "night_screen"}, True, False),
    ({"metric_a": "sleep", "metric_b": "night_screen", "recent_days": 14}, True, False),
    ({"metric_a": "sleep", "metric_b": "night_screen", "baseline_days": 7}, True, False),
    ({"metric_a": "sleep", "metric_b": "night_screen", "baseline_days": None}, True, False),
    ({"metric_a": "sleep", "metric_b": "night_screen"}, False, False),
])
def test_correlation_requirement_checks_both_metrics_window_and_usable_result(args, ok, satisfied):
    evidence = _full_sleep_evidence() + [_ev("correlate_metrics", args, ok=ok)]
    result = completion_check("Why did my sleep change?", evidence, ALL + ["correlate_metrics"])
    assert (not result.missing) == satisfied


def test_diagnostic_does_not_expand_plot_only_or_generic_agent_requirements():
    result = completion_check("Plot my sleep this week", _full_sleep_evidence(),
                              ALL + ["correlate_metrics"])
    assert not result.missing and not result.unavailable
    result = completion_check("Why did my sleep change?", _full_sleep_evidence(), ALL)
    assert not result.missing and not result.unavailable
    result = completion_check("Why did my sleep change?", [], ["compare_window"])
    assert len(result.unavailable) == 5
    assert all(req.tool_name != "correlate_metrics" for req in result.unavailable)


PLOT_DEFINITION_Q = (
    "Plot my sleep_efficiency score over the last 28 days. Explain what this measure means "
    "and whether it is the fraction of time in bed spent asleep."
)


@pytest.mark.parametrize("wrong", [None, "metric", "window", "failed"])
def test_explicit_efficiency_plot_checks_only_its_metric_window_and_result(wrong, monkeypatch):
    from datetime import date

    monkeypatch.setattr(LP.config, "DEMO_TODAY", date(2018, 6, 8))
    args = {"metric": "sleep_efficiency", "start_date": "2018-05-12", "end_date": "2018-06-08"}
    if wrong == "metric":
        args["metric"] = "night_screen_minutes"
    if wrong == "window":
        args["start_date"] = "2018-06-02"
    evidence = [_ev("plot_timeseries", args, ok=wrong != "failed")]
    result = completion_check(PLOT_DEFINITION_Q, evidence, ALL + ["correlate_metrics"])
    assert not result.unavailable
    assert [r.tool_name for r in result.missing] == ([] if wrong is None else ["plot_timeseries"])


def test_plot_uses_literal_dates_and_does_not_guess_an_unparsed_window():
    args = {"metric": "sleep_efficiency", "start_date": "2018-05-12", "end_date": "2018-06-08"}
    evidence = [_ev("plot_timeseries", args)]
    for question in ("Chart sleep_efficiency from 2018-05-12 to 2018-06-08.",
                     "Visualize sleep_efficiency for the winter term. Explain what it means."):
        result = completion_check(question, evidence, ALL + ["correlate_metrics"])
        assert not result.missing and not result.unavailable
    result = completion_check("Chart sleep_efficiency from 2018-05-13 to 2018-06-08.", evidence, ALL)
    assert [r.tool_name for r in result.missing] == ["plot_timeseries"]


def test_plot_plus_a_causal_question_keeps_the_sleep_pipeline_and_diagnostic():
    question = "Plot sleep_efficiency and explain why my sleep changed."
    assert requirements_for(question) is LP.SLEEP_REQS
    result = completion_check(question, _full_sleep_evidence(), ALL + ["correlate_metrics"])
    assert [r.tool_name for r in result.missing] == ["correlate_metrics"]
    # Defining a measure alone must never request the correlation diagnostic.
    result = completion_check("Explain what sleep_efficiency measures", _full_sleep_evidence(),
                              ALL + ["correlate_metrics"])
    assert not result.missing and not result.unavailable
