"""HA_DATA_DIR override (bring-your-own-data): the loader must read from the custom dir, with the
lru-cache cleared so the shipped data can't mask a broken override."""
import importlib
import os


def test_ha_data_dir_override(monkeypatch, tmp_path):
    prior_data_dir = os.environ.get("HA_DATA_DIR")
    from healthagent import config as config0
    from healthagent import data as data0

    # A custom data dir whose processed/sleep differs from the shipped data (sentinel value).
    proc = tmp_path / "processed"
    proc.mkdir()
    sleep = data0.load_table("sleep").copy()
    sleep["total_sleep_hours"] = 1.23
    sleep.to_parquet(proc / "sleep.parquet")

    monkeypatch.setenv("HA_DATA_DIR", str(tmp_path))  # = parent of processed/
    config = importlib.reload(config0)
    data = importlib.reload(data0)
    data.load_table.cache_clear()                     # else stale shipped data could mask the override
    try:
        assert config.PROCESSED == proc
        assert float(data.load_table("sleep")["total_sleep_hours"].iloc[0]) == 1.23
    finally:  # restore module state so other tests still see the shipped data
        if prior_data_dir is None:
            monkeypatch.delenv("HA_DATA_DIR", raising=False)
        else:
            monkeypatch.setenv("HA_DATA_DIR", prior_data_dir)
        importlib.reload(config0)
        importlib.reload(data0)
        data0.load_table.cache_clear()


def test_profile_metadata_selects_user_epoch_and_codebook(monkeypatch, tmp_path):
    prior_data_dir = os.environ.get("HA_DATA_DIR")
    import json
    from healthagent import config

    (tmp_path / "dataset_metadata.json").write_text(json.dumps({
        "demo_user": "g01_01", "demo_today": "2018-06-18", "data_kind": "hybrid",
        "codebook": "codebook.csv", "night_screen_window": "00:00-06:00",
    }))
    monkeypatch.setenv("HA_DATA_DIR", str(tmp_path))
    try:
        importlib.reload(config)
        assert config.DEMO_USER == "g01_01"
        assert config.dataset_today() == "2018-06-18"
        assert config.recent_window() == ("2018-06-12", "2018-06-18")
        assert config.CODEBOOK == tmp_path / "codebook.csv"
    finally:
        if prior_data_dir is None:
            monkeypatch.delenv("HA_DATA_DIR", raising=False)
        else:
            monkeypatch.setenv("HA_DATA_DIR", prior_data_dir)
        importlib.reload(config)
