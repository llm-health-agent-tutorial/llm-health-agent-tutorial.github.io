"""The hybrid profile must preserve source observations and identify every supplement."""
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / "data" / "globem_hybrid"
spec = importlib.util.spec_from_file_location("build_globem_hybrid", ROOT / "data" / "build_globem_hybrid.py")
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)


def test_hybrid_observations_match_pinned_source_with_missingness():
    builder.verify_public_source()
    for table, mappings in builder.MAPPING.items():
        built = pd.read_parquet(PROFILE / "processed" / f"{table}.parquet")
        for metric, (modality, column, multiplier) in mappings.items():
            raw = pd.read_csv(PROFILE / "source" / "INS-W-sample_1" / "FeatureData" / f"{modality}.csv",
                              usecols=["pid", "date", column])
            aligned = built[["source_pid", "date"]].merge(raw, left_on=["source_pid", "date"],
                                                          right_on=["pid", "date"], validate="one_to_one")
            expected = pd.to_numeric(aligned[column]) * multiplier
            pd.testing.assert_series_equal(built[metric], expected, check_names=False)
            assert built[metric].isna().sum() == raw[column].isna().sum()
        assert not built.is_imputed.any()
    # A genuine observation (486 min) is retained as 8.1 h, not overwritten by demo data.
    sleep = pd.read_parquet(PROFILE / "processed" / "sleep.parquet")
    assert sleep.loc[(sleep.source_pid == "INS-W_004") & (sleep.date == "2018-04-30"), "total_sleep_hours"].item() == 8.1
    assert sleep.total_sleep_hours.isna().sum() > 0


def test_every_hybrid_column_has_provenance_and_distinct_time_window():
    provenance = pd.read_csv(PROFILE / "field_provenance.csv").set_index(["table", "metric"])
    assert provenance.index.is_unique
    for path in (PROFILE / "processed").glob("*.parquet"):
        for metric in pd.read_parquet(path).columns:
            assert (path.stem, metric) in provenance.index
    assert provenance.loc[("sleep", "total_sleep_hours"), "origin"] == "observed"
    assert provenance.loc[("heart_rate", "hrv_rmssd_ms"), "origin"] == "synthetic"
    assert provenance.loc[("ema", "mood"), "origin"] == "synthetic"
    assert provenance.loc[("ema", "globem_negative_affect_EMA"), "origin"] == "observed"
    assert provenance.loc[("users", "steps_goal"), "origin"] == "synthetic"
    codebook = pd.read_csv(PROFILE / "codebook.csv").set_index("metric")
    assert "00:00-06:00" in codebook.loc["night_screen_minutes", "description"]
    assert "22:00-02:00" in pd.read_csv(ROOT / "data" / "codebook.csv").set_index("metric").loc["night_screen_minutes", "description"]
    metadata = json.loads((PROFILE / "dataset_metadata.json").read_text())
    assert metadata["users"] == 10 and metadata["person_days"] == 481
    assert not metadata["has_seeded_sleep_story"]


def test_hybrid_rebuild_reproduces_committed_tables_and_provenance(tmp_path):
    result = builder.build(PROFILE / "source")
    builder.write_profile(tmp_path, *result)
    for path in (PROFILE / "processed").glob("*.parquet"):
        pd.testing.assert_frame_equal(pd.read_parquet(path), pd.read_parquet(tmp_path / "processed" / path.name))
    assert (tmp_path / "field_provenance.csv").read_bytes() == (PROFILE / "field_provenance.csv").read_bytes()
    assert (tmp_path / "dataset_metadata.json").read_bytes() == (PROFILE / "dataset_metadata.json").read_bytes()
    # Supplemented mood is not substituted for or rescaled from the actual sparse PANAS EMA.
    assert len(pd.read_csv(PROFILE / "observed_ema.csv")) == 30


def test_external_source_path_requires_private_output_and_records_source_kind(tmp_path):
    # Exercise the full-data adapter's directory/CLI path using the public sample
    # fixture. This is not a claim that the credentialed full release was tested.
    command = [sys.executable, "-E", str(ROOT / "data" / "build_globem_hybrid.py"),
               "--source-dir", str(PROFILE / "source" / "INS-W-sample_1"),
               "--source-kind", "globem_credentialed"]
    refused = subprocess.run(command + ["--output-dir", str(PROFILE)], capture_output=True, text=True)
    assert refused.returncode != 0 and "outside this public tutorial repository" in refused.stderr
    completed = subprocess.run(command + ["--output-dir", str(tmp_path)], capture_output=True, text=True)
    assert completed.returncode == 0, completed.stderr
    assert json.loads((tmp_path / "dataset_metadata.json").read_text())["source_kind"] == "globem_credentialed"
    assert len(pd.read_parquet(tmp_path / "processed" / "sleep.parquet")) == 481
