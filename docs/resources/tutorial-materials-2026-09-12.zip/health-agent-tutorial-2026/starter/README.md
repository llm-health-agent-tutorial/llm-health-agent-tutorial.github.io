# Prototyping Your Personal LLM Health Agent — Starter Repo

Hands-on starter code for the **UbiComp/ISWC 2026** half-day tutorial *"From Multimodal Sensing
Data to Actionable Health Insights."* You build a single LLM **health agent** from a minimal
scaffold and ask it open-ended questions over multimodal sensing data, e.g.
*"How did my sleep change in the final week?"*

> Part 1 of a two-part track (Part 2 is the GLOSS multi-agent tutorial). This repo builds **one**
> agent from scratch; multi-agent is discussed, not built.

> Looking for the **SACI responsible-use scaffold** (refusal templates, red-team probes,
> consent minimums, IRB flowchart) from the Education Forum paper? It lives in
> [`SACI_SCAFFOLD.md`](SACI_SCAFFOLD.md).

## Quickstart (5 min)
```bash
git clone https://github.com/llm-health-agent-tutorial/llm-health-agent-starter.git && cd llm-health-agent-starter
bash install.sh          # uv-first; provisions Python 3.11, installs, registers a Jupyter kernel
source .venv/bin/activate # activate in this terminal after the installer exits
ha-check                 # preflight: python / libs / data / backend tier
make lab                 # JupyterLab on notebooks/  (pick the "health-agent" kernel)
```
Windows PowerShell: follow [SETUP.md](SETUP.md), then activate with `.\.venv\Scripts\Activate.ps1`.
Prefer a local Ollama model for the full LLM path. An API backend is optional. The deterministic
**scripted** backend supports fixed guided exercises offline, but cannot reproduce open-ended LLM reasoning. See [SETUP.md](SETUP.md) (do this at home ~2 weeks before).

## Run in your browser (no install)
Laptop trouble, or just want to peek? Two zero-install options *(active once the repo is public)*:

[![Open in GitHub Codespaces](https://github.com/codespaces/badge.svg)](https://codespaces.new/llm-health-agent-tutorial/llm-health-agent-starter)
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/llm-health-agent-tutorial/llm-health-agent-starter/main?urlpath=lab/tree/notebooks/00_preflight.ipynb)

- **Codespaces** — full VS Code in the browser with the environment pre-installed (needs a GitHub
  account + free-tier hours). Open the notebooks directly, or run `make lab` / `ha-check` in the terminal.
- **Binder** — opens JupyterLab, no account needed. Good as a backup, but **ephemeral** (edits are lost
  when the session times out) and the first launch can take a few minutes.

Both boot on the **scripted** backend (no key needed); for live models, run `make live-install` in the
browser terminal (`uv` when available, otherwise pip). **Local install (above) is still the
recommended path** — do it at home beforehand.

## What you'll do (by module)
| Module | You do | Output |
| --- | --- | --- |
| 1 · Introduction | inspect claims and map the agent workflow | evidence-question worksheet |
| 2 · Setting Up | verify env, load data, run a first tool-using call | working notebook on your backend |
| 3 · Designing Tools | implement retrieval, analysis and a time-series plot in `ha_workshop/student_tools.py` | three tested tools, including a plot with units and missing-data gaps |
| 4 · Wiring the Agent | fill three seams in `ha_workshop/agent_config.py` | an agent that answers grounded questions |
| 5 · Eval & Safety | evaluate the GLOBEM agent, then inspect a separate synthetic confound case | an evaluation & safety checklist |
| 6 · Wrap-up | review the trace and plan a next study | extension and governance plan |

**You edit only two files**, both top-level (printed by the notebooks):
`ha_workshop/student_tools.py` and `ha_workshop/agent_config.py`. The loop and the rest of
`healthagent/` are complete and read-only. The workshop agent pre-provides `compare_window` and
the correlation diagnostic `correlate_metrics`; the separate M2 baseline includes only `compare_window`.

## Layout
```
healthagent/        # the library (read-only): data, tools, registry, LLM clients, the agent loop
ha_workshop/        # YOUR code: student_tools.py, agent_config.py (+ solutions/)
data/               # default GLOBEM hybrid + separate synthetic Module-5 case and provenance
notebooks/          # 00 preflight, six module notebooks, and solutions/ reference notebooks
tests/              # contract + safety + workshop-flow tests
```

## Backends
`get_client("auto")` resolves in this order and prints a loud banner of the active tier:
`HA_BACKEND` env → reachable local Ollama → `GEMINI_API_KEY` (or `GOOGLE_API_KEY`) → `OPENAI_API_KEY` →
**scripted** (always-works
floor). All four backends are implemented. The standard install includes the Ollama SDK; `make live-install` adds hosted-provider SDKs. If a
key/model is configured but the SDK is missing, `ha-check` prints the exact fix. The **scripted**
backend is a *deterministic teaching backend*, not a real LLM: it drives the loop (reads your
registered tools, consumes observations, honors the `[GROUNDING]` clause) so your Module-4 edits
produce visible behavior changes with no key or network. **Safety handling is loop-owned** (a
deterministic preflight in `run_agent`, active once TODO-3 adds the `[REFUSAL]` clause): medical
requests get a refusal, apparent emergencies get escalation language, and self-harm/crisis requests
get crisis-support resources. It behaves identically on every backend rather than depending on a
live model's compliance.

## Safety
Incomplete edits **fail safe**: if a tool isn't implemented or the observation step isn't wired,
the agent says *"I could not gather enough evidence"* rather than inventing an answer. See
[RESPONSIBLE_USE.md](RESPONSIBLE_USE.md). This is teaching/research tooling with explicit data provenance — **not**
medical advice.

## Troubleshooting
| `ha-check` row | Fix |
| --- | --- |
| Python 3.10-3.12 FAIL | install `uv` or conda; we pin 3.11 (the supported range is 3.10-3.12) |
| Core libraries FAIL | re-run `bash install.sh`; ensure the `.venv` is active |
| Teaching dataset FAIL | check the bundled `data/globem_hybrid/` files and its data card; `make data` rebuilds the GLOBEM main profile; `make data-synthetic` rebuilds the separate case |
| kernel not in venv (notebook) | pick the **health-agent** Jupyter kernel (cell prints `sys.executable`) |


## Datasets and provenance

The **GLOBEM public-sample hybrid is the default main exercise**. A separate fully synthetic
case supports the Module 5 discussion of confounding. Do not pool them.

| Profile | Contents | Teaching role / selection |
| --- | --- | --- |
| `data/globem_hybrid/processed/` (default) | Official GLOBEM public sample observations with labeled synthetic supplements; 10 users, 481 person-days | M1–M4 and M6 main exercise; demo `g10`, dataset date `2018-06-08` |
| `data/processed/` | 12 fictional users, 112 days each, 9 tables | M5 sleep/screen/deadline case; explicit `HA_DATA_DIR=data` for a separate agent process |

The main case compares recorded sleep (recent about 5.05 h versus baseline 6.40 h) and night screen
(about 53.91 versus 38.03 min). Source-day alignment does **not** establish same-night alignment or a
causal relationship. The public-sample profile has no planted explanation for these observations.

The hybrid is **not the full credentialed PhysioNet release**. Observed missing values remain missing.
Heart rate, context and user goals are synthetic teaching values, not observations about source participants.
Read the [hybrid data card](data/globem_hybrid/DATA_CARD.md) and [field origins](data/globem_hybrid/field_provenance.csv).
Its night-screen window is 00:00–06:00; the separate synthetic case uses 22:00–02:00.

Run from the repository root in a fresh process:

```bash
HA_BACKEND=scripted python -m healthagent.verify
HA_BACKEND=scripted python -m healthagent.cli.chat -q "How did my sleep change in the final week?"
# Select HA_BACKEND=ollama for a prepared local model.
# The separate synthetic agent case, only when explicitly needed:
HA_DATA_DIR=data HA_BACKEND=scripted python -m healthagent.cli.chat -q "Why have I been sleeping poorly this week?"
```

The notebook prints the active profile, user and date. A stale `HA_DATA_DIR=data` in your shell or `.env`
selects the synthetic case instead of the main exercise. Set the profile before starting Python/Jupyter;
do not reload profile configuration in one kernel. M5 reads its separate synthetic tables directly for
manual comparison and leaves the main agent's profile unchanged.

## Complete teaching materials

[Participant/instructor materials index](MATERIALS.md) covers all six modules, reference notebooks,
optional advanced exercises, setup, data provenance, panel support and slides.

`grounded=True` means all extracted numbers match some tool-summary number within the documented tolerance.
This is a minimal numeric screen. It does not verify metric identity, units, direction words or causal claims.
The change tool's legacy `significant` flag is a descriptive threshold, not statistical significance.

## Beyond the tutorial
- **[BRING_YOUR_OWN_DATA.md](BRING_YOUR_OWN_DATA.md)** — point the agent at your own wearable/sensing
  data (`HA_DATA_DIR` + `ha-data-check`).
- **[EXTENDING.md](EXTENDING.md)** / **[docs/cookbook.md](docs/cookbook.md)** — add tools, metrics,
  backends, probes; short runnable recipes.
- CLIs: `ha-chat` (chat over the data), `ha-eval` (red-team scorecard across backends),
  `ha-data-check` (validate a dataset).

## Citation
If you use this repository or its teaching material, please cite it — see [CITATION.cff](CITATION.cff)
(GitHub's "Cite this repository" button renders it).

## Contributing
See [CONTRIBUTING.md](CONTRIBUTING.md) and the [ROADMAP.md](ROADMAP.md). Data adapters for real exports
are a great first contribution.

## License
Tutorial code and original synthetic materials: MIT, see [LICENSE](LICENSE). GLOBEM upstream
files retain their own notices and Apache-2.0 license in [data/globem_hybrid](data/globem_hybrid/README.md).
