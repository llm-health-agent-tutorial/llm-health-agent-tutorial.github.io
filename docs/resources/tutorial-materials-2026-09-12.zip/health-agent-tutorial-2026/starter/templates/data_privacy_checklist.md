# Data privacy and provenance checklist

Use this worksheet before loading a new profile, calling a model, sharing a trace, or publishing
results. Record decisions rather than assuming that “public,” “synthetic,” or “de-identified” settles
all permissions and privacy questions.

Profile / version: ____________________  
Reviewer / date: ____________________  
Intended use and audience: ____________________

## 1. Identify what you actually have

- [ ] Classify the data: fully synthetic / official public sample / credentialed complete release /
      other authorized data. Record the precise source.
- [ ] Read the profile's DATA_CARD, NOTICE, licence, source manifest, and field_provenance file.
- [ ] Distinguish observed, derived, synthetic, and unavailable fields. Confirm that aliases do not
      hide a change of meaning or establish additional anonymity.
- [ ] Preserve observed missingness. Do not present synthetic supplements as validated imputations,
      participant reports, demographic facts, or measured physiology.
- [ ] Check user, date range, units, timezone conventions, and metric windows from profile metadata.
      The GLOBEM public sample's night segment is 00:00–06:00; the synthetic default is 22:00–02:00.
- [ ] Start a fresh process or restart the notebook kernel when changing HA_DATA_DIR.

## 2. Separate public sample access from complete-data access

- [ ] For the bundled official public GLOBEM sample, retain upstream attribution, the Apache 2.0
      licence and notices, source paths, pinned commit, and hashes.
- [ ] Do not imply that the public sample grants access to the full PhysioNet GLOBEM release.
- [ ] For complete credentialed data, confirm your own authorization, required training, and signed
      data-use agreement before obtaining or processing it.
- [ ] Keep credentialed inputs and outputs outside the public tutorial repository and release bundle.
      Adding synthetic columns does not make restricted observations redistributable.
- [ ] Check whether derived tables, screenshots, model traces, or examples may be shared under the
      actual source terms; record the decision.
- [ ] State that the complete credentialed dataset has not been tested when using the provided
      adapter without a full-data validation run.

## 3. Minimize model and tool exposure

- [ ] Expose only the users, dates, columns, and aggregation level needed for the question.
- [ ] Avoid precise locations, direct identifiers, and unnecessary free text in tool outputs.
- [ ] Prefer local processing for the tutorial. Before using a hosted provider, confirm that the
      selected data may be transmitted and review the applicable retention and account settings.
- [ ] Do not place credentials in notebooks, slides, prompts, logs, screenshots, or survey answers.
- [ ] Know where data, caches, figures, and transcripts are written and who can access them.

## 4. Interpret and report honestly

- [ ] Report associations in observed data with missingness and coverage; do not imply a
      representative sample or causal identification.
- [ ] Do not use synthetic heart rate, context, goals, or demographic fields as evidence about
      a real GLOBEM participant.
- [ ] Separate findings on observed variables from demonstrations involving synthetic supplements.
- [ ] Treat the minimum numeric grounding flag as one check, not validation of every fact,
      metric attribution, causal conclusion, or safety boundary.
- [ ] Document backend/model and profile for each result; label scripted runs as fixed-example
      control-flow demonstrations.

## 5. Before a study or release

- [ ] Confirm the relevant institutional ethics, consent, security, and data-governance requirements
      for the actual project; this checklist does not determine an IRB outcome.
- [ ] Establish a retention/deletion schedule, access permissions, and an incident contact.
- [ ] Inspect exported notebooks and slides for personal data, restricted records, keys, and hidden
      outputs before sharing.
- [ ] Include source attribution, provenance, limitations, and permitted-use information with the
      shared artifact.
- [ ] Record unresolved issues and stop the affected processing or sharing step until resolved.

Unresolved issue / owner / next action: ___________________________________________

References: [Responsible use](../RESPONSIBLE_USE.md),
[default data card](../data/DATA_CARD.md),
[hybrid data card](../data/globem_hybrid/DATA_CARD.md),
[hybrid source notice](../data/globem_hybrid/NOTICE.md).
